#!/usr/bin/env python
# coding: utf-8

# In[1]:


""" 
The module DPMFA_FoR_Comp_POL_ZnO_Dynamic_model sets compartments and flows required to model the fate of ZnO engineered nanomaterials through their lifecycle and towards the environment.
The system studied is Poland from 2000 to 2020, with a yearly timestep.
This module needs to be modified if the system (compartments, transfer coefficients, uncertainties) are modified.
"""


# In[ ]:


import components as cp
import numpy.random as nr
import numpy as np
import Model
import pandas as pd

import TruncatingFunctions as tf 


# In[2]:


model = Model.Model('nano-ZnO POL from 2000 to 2020/2030')


# In[3]:


### DEFINE THE COMPARTMENTS OF THE MODEL

# split of the total inflow to different compartments
Inflow_Prod = cp.FlowCompartment('Inflow_Prod', logInflows=True, logOutflows=True)
Import_Manuf = cp.FlowCompartment('Import_Manuf', logInflows=True, logOutflows=True, categories=['Import'])
Import_Cons = cp.FlowCompartment('Import_Cons', logInflows=True, logOutflows=True, categories=['Import'])


# In[4]:


# Production of the nano-material and Manufacturing of the products it is used in   
Production  = cp.Stock('Production',  logInflows=True, logOutflows=True, logImmediateFlows=True, categories=['Production'])
Manufacture = cp.Stock('Manufacture', logInflows=True, logOutflows=True, logImmediateFlows=True, categories=['Manufacture'])
Consumption = cp.FlowCompartment('Consumption', logInflows=True, logOutflows=True, categories=['Consumption'])


# In[5]:


Prod_Air_N = cp.Sink('Pristine from Prod to Air', logInflows=True, categories=['Air', 'Air_N', 'Pristine'])
Manuf_Air_N = cp.Sink('Pristine from Manuf to Air', logInflows=True, categories=['Air', 'Air_N', 'Pristine'])


# In[6]:


# Manufacturing and waste
Manuf_Antibact = cp.FlowCompartment('Manuf Antibact products', logInflows=True, logOutflows=True, categories=['Manufacture'])
Manuf_Liquids = cp.FlowCompartment('Manuf Liquids', logInflows=True, logOutflows=True, categories=['Manufacture'])

Manuf_Antibact_Waste = cp.FlowCompartment('Waste from manufactured antibacterial products', logInflows=True, logOutflows=True, categories=['Solid Waste'])
manuf_textiles_waste = cp.FlowCompartment('Waste from manufactured textile antibact products', logInflows=True, logOutflows=True, categories=['Solid Waste'])
manuf_plastics_waste = cp.FlowCompartment('Waste from manufactured plastic antibact products', logInflows=True, logOutflows=True, categories=['Solid Waste'])


# In[7]:


# Definition of Product categories
PersCare = cp.FlowCompartment('Personal Care', logInflows=True, logOutflows=True, categories='Products')
PersCare_Use = cp.Stock('PersCare_Use', logInflows=True, logOutflows=True, logImmediateFlows=True, categories=['PMC','Use','PMCrel'])
PersCare_EoL = cp.Stock('PersCare_EoL', logInflows=True, logOutflows=True, logImmediateFlows=True, categories=['PMC','EoL'])

PainLacq = cp.FlowCompartment('Paints & lacquers', logInflows=True, logOutflows=True, categories='Products')
PainLacq_Use = cp.Stock('PainLacq_Use', logInflows=True, logOutflows=True, logImmediateFlows=True, categories=['PMC','Use','PMCrel'])
PainLacq_EoL = cp.Stock('PainLacq_EoL', logInflows=True, logOutflows=True, logImmediateFlows=True, categories=['PMC','EoL'])

Antibact = cp.FlowCompartment('Antibacterial', logInflows=True, logOutflows=True, categories=['Products'])
Antibact_Use = cp.Stock('Antibact_Use', logInflows=True, logOutflows=True, logImmediateFlows=True, categories=['PMC','Use','PMCrel'])
Antibact_EoL = cp.Stock('Antibact_EoL', logInflows=True,logOutflows=True,logImmediateFlows=True, categories=['PMC','EoL'])


# In[8]:


# Definition of forms of release after use
PersCare_WW = cp.FlowCompartment('PersCare in wastewater', logInflows=True, logOutflows=True, categories=['Wastewater'])
PersCare_WW_D = cp.FlowCompartment('Dissolved from PersCare in wastewater', logInflows=True, logOutflows=True, categories=['Wastewater_D', 'Dissolved'])
PersCare_WW_N = cp.FlowCompartment('Pristine from PersCare in wastewater', logInflows=True, logOutflows=True, categories=['Wastewater_N', 'Pristine'])
PersCare_SW = cp.FlowCompartment('PersCare in Surface water', logInflows=True, logOutflows=True, categories=['Surfacewater'])
PersCare_SW_D = cp.Sink('Dissolved from PersCare in Surface water', logInflows=True, categories=['Surfacewater_D', 'Dissolved'])
PersCare_SW_N = cp.Sink('Pristine from PersCareLiquids in Surface water', logInflows=True, categories=['Surfacewater_N', 'Pristine'])

PainLacq_WW = cp.FlowCompartment('Paints & lacquers in wastewater', logInflows=True, logOutflows=True, categories=['Wastewater'])
PainLacq_WW_N = cp.FlowCompartment('Pristine from paints & lacquers in wastewater', logInflows=True, logOutflows=True, categories=['Wastewater_N', 'Pristine'])
PainLacq_WW_T = cp.FlowCompartment('Transformed from paints & lacquers in wastewater', logInflows=True, logOutflows=True, categories=['Wastewater_T', 'Transformed'])
PainLacq_WW_D = cp.FlowCompartment('Dissolved from paints & lacquers in wastewater', logInflows=True, logOutflows=True, categories=['Wastewater_D', 'Dissolved'])
PainLacq_WW_M = cp.FlowCompartment('Matrix-embedded from paints & lacquers in wastewater', logInflows=True, logOutflows=True, categories=['Wastewater_M', 'Matrix-embedded'])

PainLacq_Air = cp.FlowCompartment('Paints & lacquers in Air', logInflows=True, logOutflows=True, categories=['Air'])
PainLacq_Air_M = cp.Sink('Matrix-embedded from paints & lacquers in Air', logInflows=True, categories=['Air_M', 'Matrix-embedded'])

PainLacq_NUsoil = cp.FlowCompartment('Paints & lacquers in Soil', logInflows=True, logOutflows=True, categories=['Soil', 'NU Soil'])
PainLacq_NUsoil_N = cp.Sink('Pristine from paints & lacquers in Soil', logInflows=True, categories=['Soil_N', 'NU Soil_N', 'Pristine'])
PainLacq_NUsoil_T = cp.Sink('Transformed from paints & lacquers in Soil', logInflows=True, categories=['Soil_T', 'NU Soil_T', 'Transformed'])
PainLacq_NUsoil_D = cp.Sink('Dissolved from paints & lacquers in Soil', logInflows=True, categories=['Soil_D', 'NU Soil_D', 'Dissolved'])
PainLacq_NUsoil_M = cp.Sink('Matrix-embedded from paints & lacquers in Soil', logInflows=True, categories=['Soil_M', 'NU Soil_M', 'Matrix-embedded'])

# Textiles are used as a proxy for antibacterials
Antibact_Air = cp.FlowCompartment('Antibacterials in Air', logInflows=True, logOutflows=True, categories=['Air'])
Antibact_Air_N = cp.Sink('Pristine from Antibacterials in Air', logInflows=True, categories=['Air_N', 'Pristine'])
Antibact_Air_M = cp.Sink('Matrix-embedded from Antibacterials in Air', logInflows=True, categories=['Air_M', 'Matrix-embedded'])

Antibact_WW = cp.FlowCompartment('Antibacterials in Wastewater', logInflows=True, logOutflows=True, categories=['Wastewater'])
Antibact_WW_N = cp.FlowCompartment('Pristine from Antibacterials in Wastewater', logInflows=True, logOutflows=True, categories=['Wastewater_N', 'Pristine'])
Antibact_WW_M = cp.FlowCompartment('Matrix-embedded from Antibacterials in Wastewater', logInflows=True, logOutflows=True, categories=['Wastewater_M', 'Matrix-embedded'])
Antibact_WW_T = cp.FlowCompartment('Transformed from Antibacterials in Wastewater', logInflows=True, logOutflows=True, categories=['Wastewater_T','Transformed'])
Antibact_WW_D = cp.FlowCompartment('Dissolved from Antibacterials in Wastewater', logInflows=True, logOutflows=True, categories=['Wastewater_D', 'Dissolved'])                                                                                                                                    


# In[9]:


# Definition of WIP compartments 
WIP_P = cp.FlowCompartment('Product-embedded to Waste Incineration Plant', logInflows=True, logOutflows=True, categories=['WIP', 'WIP_P', 'Product-embedded']) 
WIP_T = cp.FlowCompartment('Transformed to Waste Incineration Plant', logInflows=True, logOutflows=True, categories=['WIP', 'WIP_T', 'Transformed']) 
WIP_M = cp.FlowCompartment('Matrix-embedded to Waste Incineration Plant', logInflows=True, logOutflows=True, categories=['WIP', 'WIP_M', 'Matrix-embedded'])

Burning_N = cp.FlowCompartment('Pristine after Burning', logInflows=True, logOutflows=True, categories=['Burning', 'Burning_N', 'Pristine'])
Burning_T = cp.FlowCompartment('Transformed after Burning', logInflows=True, logOutflows=True, categories=['Burning', 'Burning_T', 'Transformed'])

Bottomash_N = cp.FlowCompartment('Pristine in Bottom ash', logInflows=True, logOutflows=True, categories=['Bottom ash', 'Bottom ash_N', 'Pristine'])
Bottomash_T = cp.FlowCompartment('Transformed in Bottom ash', logInflows=True, logOutflows=True, categories=['Bottom ash', 'Bottom ash_T', 'Transformed'])
Flyash_N = cp.FlowCompartment('Pristine in Flyash', logInflows=True, logOutflows=True, categories=['Flyash', 'Flyash_N', 'Pristine'])
Flyash_T = cp.FlowCompartment('Transformed in Flyash', logInflows=True, logOutflows=True, categories=['Flyash', 'Flyash_T', 'Transformed'])
Filterash_N = cp.FlowCompartment('Pristine in Filterash', logInflows=True, logOutflows=True, categories=['Filterash', 'Filterash_N', 'Pristine'])
Filterash_T = cp.FlowCompartment('Transformed in Filterash', logInflows=True, logOutflows=True, categories=['Filterash', 'Filterash_T', 'Transformed'])

Acidwashing_N = cp.FlowCompartment('Pristine to Acid Washing', logInflows=True, logOutflows=True, categories=['AcidWashing', 'AcidWashing_N', 'Pristine'])
Acidwashing_T = cp.FlowCompartment('Transformed to Acid Washing', logInflows=True, logOutflows=True, categories=['AcidWashing', 'AcidWashing_T', 'Transformed'])

WIP_Air_N = cp.Sink('Pristine from WIP to Air', logInflows=True, categories=['Air', 'Air_N', 'Pristine'])
WIP_Air_T = cp.Sink('Transformed from WIP to Air', logInflows=True, categories=['Air', 'Air_T', 'Transformed'])


# In[10]:


# Definition of wastewater collection and treatment
WW_N  = cp.FlowCompartment('Pristine in Wastewater', logInflows=True, logOutflows=True, categories=['AllWastewater', 'AllWastewater_N', 'Pristine'])
WW_M  = cp.FlowCompartment('Matrix-embedded in Wastewater', logInflows=True, logOutflows=True, categories=['AllWastewater', 'AllWastewater_M', 'Matrix-embedded'])
WW_T  = cp.FlowCompartment('Transformed in Wastewater', logInflows=True, logOutflows=True, categories=['AllWastewater', 'AllWastewater_T', 'Transformed'])
WW_D  = cp.FlowCompartment('Dissolved in Wastewater', logInflows=True, logOutflows=True, categories=['AllWastewater', 'AllWastewater_D', 'Dissolved'])

NoSewageSystem_N = cp.FlowCompartment('Pristine in NoSewageSystem', logInflows=True, logOutflows=True, categories=['NoSewageSystem', 'NoSewageSystem_N', 'Pristine'])
NoSewageSystem_T = cp.FlowCompartment('Transformed in NoSewageSystem', logInflows=True, logOutflows=True, categories=['NoSewageSystem', 'NoSewageSystem_T', 'Transformed'])
NoSewageSystem_M = cp.FlowCompartment('Matrix-embedded in NoSewageSystem', logInflows=True, logOutflows=True, categories=['NoSewageSystem', 'NoSewageSystem_M', 'Matrix-embedded'])
NoSewageSystem_D = cp.FlowCompartment('Dissolved in NoSewageSystem', logInflows=True, logOutflows=True, categories=['NoSewageSystem', 'NoSewageSystem_D', 'Dissolved'])

SewageSystem_N = cp.FlowCompartment('Pristine in SewageSystem', logInflows=True, logOutflows=True, categories=['SewageSystem', 'SewageSystem_N', 'Pristine'])
SewageSystem_T = cp.FlowCompartment('Transformed in SewageSystem', logInflows=True, logOutflows=True, categories=['SewageSystem', 'SewageSystem_T', 'Transformed'])
SewageSystem_M = cp.FlowCompartment('Matrix-embedded in SewageSystem', logInflows=True, logOutflows=True, categories=['SewageSystem', 'SewageSystem_M', 'Matrix-embedded'])
SewageSystem_D = cp.FlowCompartment('Dissolved in SewageSystem', logInflows=True, logOutflows=True, categories=['SewageSystem', 'SewageSystem_D', 'Dissolved'])

OnSiteTreat_N = cp.FlowCompartment('Pristine in OnsiteTreat', logInflows=True, logOutflows=True, categories=['OnsiteTreat', 'OnsiteTreat_N', 'Pristine'])
OnSiteTreat_M = cp.FlowCompartment('Matrix-embedded in OnsiteTreat', logInflows=True, logOutflows=True, categories=['OnsiteTreat', 'OnsiteTreat_M', 'Matrix-embedded'])
OnSiteTreat_T = cp.FlowCompartment('Transformed in OnsiteTreat', logInflows=True, logOutflows=True, categories=['OnsiteTreat', 'OnsiteTreat_T', 'Transformed'])
OnSiteTreat_D = cp.FlowCompartment('Dissolved in OnsiteTreat', logInflows=True, logOutflows=True, categories=['OnsiteTreat', 'OnsiteTreat_D', 'Dissolved'])

EndOfSewer_M = cp.FlowCompartment('Matrix-embedded in EndOfSewer', logInflows=True, logOutflows=True, categories=['EndOfSewer', 'EndOfSewer_M', 'Matrix-embedded'])
EndOfSewer_T = cp.FlowCompartment('Transformed in EndOfSewer', logInflows=True, logOutflows=True, categories=['EndOfSewer', 'EndOfSewer_T', 'Transformed'])
EndOfSewer_D = cp.FlowCompartment('Dissolved in EndOfSewer', logInflows=True, logOutflows=True, categories=['EndOfSewer', 'EndOfSewer_D', 'Dissolved'])

WWTP_M = cp.FlowCompartment('Matrix-embedded in WWTP', logInflows=True, logOutflows=True, categories=['WWTP', 'WWTP_M', 'Matrix-embedded'])
WWTP_T = cp.FlowCompartment('Transformed in WWTP', logInflows=True, logOutflows=True, categories=['WWTP', 'WWTP_T', 'Transformed'])
WWTP_D = cp.FlowCompartment('Dissolved in WWTP', logInflows=True, logOutflows=True, categories=['WWTP', 'WWTP_D', 'Dissolved'])

TreatI_M = cp.FlowCompartment('Matrix-embedded in TreatI', logInflows=True, logOutflows=True, categories=['STP', 'STP_M', 'Treat', 'Treat_M', 'TreatI_M', 'Matrix-embedded'])
TreatI_T = cp.FlowCompartment('Transformed in TreatI', logInflows=True, logOutflows=True, categories=['STP', 'STP_T', 'Treat', 'Treat_T', 'TreatI', 'TreatI_T', 'Transformed'])
TreatI_D = cp.FlowCompartment('Dissolved in TreatI', logInflows=True, logOutflows=True, categories=['STP', 'STP_D', 'Treat', 'Treat_D', 'TreatI', 'TreatI_D', 'Dissolved'])

TreatII_M = cp.FlowCompartment('Matrix-embedded in TreatII', logInflows=True, logOutflows=True, categories=['STP', 'STP_M', 'Treat', 'Treat_M', 'TreatII', 'TreatII_M', 'Matrix-embedded'])
TreatII_T = cp.FlowCompartment('Transformed in TreatII', logInflows=True, logOutflows=True, categories=['STP', 'STP_T', 'Treat', 'Treat_T', 'TreatII', 'TreatII_T', 'Transformed'])
TreatII_D = cp.FlowCompartment('Dissolved in TreatII', logInflows=True, logOutflows=True, categories=['STP', 'STP_D', 'Treat', 'Treat_D', 'TreatII', 'TreatII_D', 'Dissolved'])

TreatIII_M = cp.FlowCompartment('Matrix-embedded in TreatIII', logInflows=True, logOutflows=True, categories=['STP', 'STP_M', 'Treat', 'Treat_M', 'TreatIII', 'TreatIII_M', 'Matrix-embedded'])
TreatIII_T = cp.FlowCompartment('Transformed in TreatIII', logInflows=True, logOutflows=True, categories=['STP', 'STP_T', 'Treat', 'Treat_T', 'TreatIII', 'TreatIII_T', 'Transformed'])
TreatIII_D = cp.FlowCompartment('Dissolved in TreatIII', logInflows=True, logOutflows=True, categories=['STP', 'STP_D', 'Treat', 'Treat_D', 'TreatIII', 'TreatIII_D', 'Dissolved'])

TreatIOnsite_N = cp.FlowCompartment('Pristine in TreatIOnsite', logInflows=True, logOutflows=True, categories=['Treat', 'Treat_N', 'TreatIOnsite', 'TreatIOnsite_N', 'Pristine'])
TreatIOnsite_M = cp.FlowCompartment('Matrix-embedded in TreatIOnsite', logInflows=True, logOutflows=True, categories=['Treat', 'Treat_M', 'TreatIOnsite', 'TreatIOnsite_M', 'Matrix-embedded'])
TreatIOnsite_T = cp.FlowCompartment('Transformed in TreatIOnsite', logInflows=True, logOutflows=True, categories=['Treat', 'Treat_T', 'TreatIOnsite', 'TreatIOnsite_T', 'Transformed'])
TreatIOnsite_D = cp.FlowCompartment('Dissolved in TreatIOnsite', logInflows=True, logOutflows=True, categories=['Treat', 'Treat_D', 'TreatIOnsite', 'TreatIOnsite_D', 'Dissolved'])

EndOfTreatI_M = cp.FlowCompartment('Matrix-embedded in EndOfTreatI', logInflows=True, logOutflows=True, categories=['STP_End', 'STP_End_M', 'Treat_End', 'Treat_End_M', 'TreatI_End', 'TreatI_End_M', 'Matrix-embedded'])
EndOfTreatI_T = cp.FlowCompartment('Transformed in EndOfTreatI', logInflows=True, logOutflows=True, categories=['STP_End', 'STP_End_T', 'Treat_End', 'Treat_End_T', 'TreatI_End_T', 'Transformed'])

EndOfTreatII_M = cp.FlowCompartment('Matrix-embedded in EndOfTreatII', logInflows=True, logOutflows=True, categories=['STP_End', 'STP_End_M', 'Treat_End', 'Treat_End_M', 'TreatII_End', 'TreatII_End_M', 'Matrix-embedded'])
EndOfTreatII_T = cp.FlowCompartment('Transformed in EndOfTreatII', logInflows=True, logOutflows=True, categories=['STP_End', 'STP_End_T', 'Treat_End', 'Treat_End_T', 'TreatII_End', 'TreatII_End_T' 'Transformed'])

EndOfTreatIII_M = cp.FlowCompartment('Matrix-embedded in EndOfTreatIII', logInflows=True, logOutflows=True, categories=['STP_End', 'STP_End_M', 'Treat_End', 'Treat_End_M', 'TreatIII_End', 'TreatIII_End_M', 'Matrix-embedded'])
EndOfTreatIII_T = cp.FlowCompartment('Transformed in EndOfTreatIII', logInflows=True, logOutflows=True, categories=['STP_End', 'STP_End_T', 'Treat_End', 'Treat_End_T', 'TreatIII_End', 'TreatIII_End_T', 'Transformed'])

EndOfTreatIOnsite_N = cp.FlowCompartment('Pristine in EndOfTreatIOnsite', logInflows=True, logOutflows=True, categories=['Treat_End', 'Treat_End_N', 'TreatIOnsite_End', 'TreatIOnsite_End_N', 'Pristine'])
EndOfTreatIOnsite_M = cp.FlowCompartment('Matrix-embedded in EndOfTreatIOnsite', logInflows=True, logOutflows=True, categories=['Treat_End', 'Treat_End_M', 'TreatIOnsite_End', 'TreatIOnsite_End_M', 'Matrix-embedded'])
EndOfTreatIOnsite_T = cp.FlowCompartment('Transformed in EndOfTreatIOnsite', logInflows=True, logOutflows=True, categories=['Treat_End', 'Treat_End_T', 'TreatIOnsite_End', 'TreatIOnsite_End_T', 'Transformed'])

STPoverflow_M = cp.FlowCompartment('Matrix-embedded in STPoverflow', logInflows=True, logOutflows=True, categories=['Overflow', 'Overflow_M', 'Matrix-embedded'])
STPoverflow_T = cp.FlowCompartment('Transformed in STPoverflow', logInflows=True, logOutflows=True, categories=['Overflow', 'Overflow_T', 'Transformed'])
STPoverflow_D = cp.FlowCompartment('Dissolved in STPoverflow', logInflows=True, logOutflows=True, categories=['Overflow', 'Overflow_D', 'Dissolved'])

STPeffluent_M = cp.FlowCompartment('Matrix-embedded in STPeffluent', logInflows=True, logOutflows=True, categories=['STPeffluent', 'STPeffluent_M', 'Matrix-embedded'])
STPeffluent_T = cp.FlowCompartment('Transformed in STPeffluent', logInflows=True, logOutflows=True, categories=['STPeffluent', 'STPeffluent_T', 'Transformed'])

STPsludge_M = cp.FlowCompartment('Matrix-embedded in STPsludge', logInflows=True, logOutflows=True, categories=['STPsludge', 'STPsludge_M', 'Matrix-embedded'])
STPsludge_T = cp.FlowCompartment('Transformed in STPsludge', logInflows=True, logOutflows=True, categories=['STPsludge', 'STPsludge_T', 'Transformed'])


# In[11]:


# Definition of solid wastes
MMSW = cp.FlowCompartment('MMSW', logInflows=True, logOutflows=True, categories=['SolidWaste', 'PMCrel'])
PackW = cp.FlowCompartment('PackW', logInflows=True, logOutflows=True, categories=['SolidWaste','PMCrel'])
CDW = cp.FlowCompartment('CDW', logInflows=True, logOutflows=True, categories=['SolidWaste', 'PMCrel'])


# In[12]:


# Definition of sorting:

# Packaging waste
Sorting_PackW = cp.FlowCompartment('Sorting_PackW', logInflows=True, logOutflows=True, categories=['Sorting', 'Sorting1'])

# Construction and demolition waste
Sorting_CDW = cp.FlowCompartment('Sorting_CDW', logInflows=True, logOutflows=True, categories=['Sorting', 'Sorting1'])
Sorting_CDW_Mineral = cp.FlowCompartment('Sorting_CDW_Mineral', logInflows=True, logOutflows=True, categories=['Sorting', 'Sorting2'])


# In[13]:


# Definition of Export
Export = cp.Sink('Export', logInflows=True, categories=['Export'])


# In[14]:


# Definition of Landfill
Manuf_Landfill_P = cp.Sink('Product-embedded from manufacturing waste to Landfill', logInflows=True, categories=['Landfill', 'Landfill_P', 'Product-embedded'])
Slud_Landfill_M = cp.Sink('Matrix-embedded from STP sludge to Landfill', logInflows=True, categories=['Landfill', 'Landfill_M', 'Matrix-embedded'])
Slud_Landfill_T = cp.Sink('Transformed from STP sludge to Landfill', logInflows=True, categories=['Landfill', 'Landfill_T', 'Transformed'])
MMSW_Landfill_P = cp.Sink('Product-embedded from MMSW to Landfill', logInflows=True, categories=['Landfill', 'Landfill_P', 'Product-embedded'])
CDW_Landfill_P = cp.Sink('Product-embedded from CDW to Landfill', logInflows=True, categories=['Landfill', 'Landfill_P', 'Product-embedded'])
SortCDW_Landfill_P = cp.Sink('Product-embedded from CDW Mineral Sorting to Landfill', logInflows=True, categories=['Landfill', 'Landfill_P', 'Product-embedded'])
SortCDWMiner_Landfill_P = cp.Sink('Product-embedded from Sorted Mineral to Landfill', logInflows=True, categories=['Landfill', 'Landfill_P', 'Product-embedded'])
Filterash_Landfill_N = cp.Sink('Pristine from Filter ash to Landfill', logInflows=True, categories=['Landfill', 'Landfill_N', 'Pristine'])
Filterash_Landfill_T = cp.Sink('Transformed from Filter ash to Landfill', logInflows=True, categories=['Landfill', 'Landfill_T', 'Transformed'])
Bottomash_Landfill_N = cp.Sink('Pristine from Bottom ash to Landfill', logInflows=True, categories=['Landfill', 'Landfill_N', 'Pristine'])
Bottomash_Landfill_T = cp.Sink('Transformed from Bottom ash to Landfill', logInflows=True, categories=['Landfill', 'Landfill_T', 'Transformed'])


# In[15]:


# Definition of Sludge treated soil
STsoil_T = cp.Sink('Transformed in Sludge treated soil', logInflows=True, categories=['Soil', 'Soil_T', 'ST Soil', 'ST Soil_T', 'Transformed'])
STsoil_M = cp.Sink('Matrix-embedded in Sludge treated soil', logInflows=True, categories=['Soil', 'Soil_M', 'ST Soil', 'ST Soil_M', 'Matrix-embedded'])

# Definition of Surfacewater
NoSew_SurfWater_N = cp.Sink('Pristine from No sewer to Surfacewater', logInflows=True, categories=['Surfacewater', 'Surfacewater_N', 'Pristine'])
NoSew_SurfWater_M = cp.Sink('Matrix-embedded from No sewer to Surfacewater', logInflows=True, categories=['Surfacewater', 'Surfacewater_M', 'Matrix-embedded'])
NoSew_SurfWater_T = cp.Sink('Transformed from No sewer to Surfacewater', logInflows=True, categories=['Surfacewater', 'Surfacewater_T', 'Transformed'])
NoSew_SurfWater_D = cp.Sink('Dissolved from No sewer to Surfacewater', logInflows=True, categories=['Surfacewater', 'Surfacewater_D', 'Dissolved'])
Sew_SurfWater_N = cp.Sink('Pristine from Sewer to Surfacewater', logInflows=True, categories=['Surfacewater', 'Surfacewater_N', 'Pristine'])
Sew_SurfWater_M = cp.Sink('Matrix-embedded from Sewer to Surfacewater', logInflows=True, categories=['Surfacewater', 'Surfacewater_M', 'Matrix-embedded'])
Sew_SurfWater_T = cp.Sink('Transformed from Sewer to Surfacewater', logInflows=True, categories=['Surfacewater', 'Surfacewater_T', 'Transformed'])
Sew_SurfWater_D = cp.Sink('Dissolved from Sewer to Surfacewater', logInflows=True, categories=['Surfacewater', 'Surfacewater_D', 'Dissolved'])
STPoverflow_SurfWater_M = cp.Sink('Matrix-embedded from STP overflow to Surfacewater', logInflows=True, categories=['Surfacewater', 'Surfacewater_M', 'Matrix-embedded'])
STPoverflow_SurfWater_T = cp.Sink('Transformed from STP overflow to Surfacewater', logInflows=True, categories=['Surfacewater', 'Surfacewater_T', 'Transformed'])
STPoverflow_SurfWater_D = cp.Sink('Dissolved from STP overflow to Surfacewater', logInflows=True, categories=['Surfacewater', 'Surfacewater_D', 'Dissolved'])
STPeffluent_SurfWater_M = cp.Sink('Matrix-embedded from STP effluent to Surfacewater', logInflows=True, categories=['Surfacewater', 'Surfacewater_M', 'Matrix-embedded'])
STPeffluent_SurfWater_T = cp.Sink('Transformed from STP effluent to Surfacewater', logInflows=True, categories=['Surfacewater', 'Surfacewater_T', 'Transformed'])

# Definition of Subsurface
EndSewer_Subsurface_M = cp.Sink('Matrix-embedded from End of Sewer to Subsurface', logInflows=True, categories=['Subsurface', 'Subsurface_M', 'Matrix-embedded'])
EndSewer_Subsurface_T = cp.Sink('Transformed from End of Sewer to Subsurface', logInflows=True, categories=['Subsurface', 'Subsurface_T', 'Transformed'])
EndSewer_Subsurface_D = cp.Sink('Dissolved from End of Sewer to Subsurface', logInflows=True, categories=['Subsurface', 'Subsurface_D', 'Dissolved'])
EndOnSiteTreat_Subsurface_N = cp.Sink('Pristine from End of On-site treatment to Subsurface', logInflows=True, categories=['Subsurface', 'Subsurface_N', 'Pristine'])
EndOnSiteTreat_Subsurface_T = cp.Sink('Transformed from End of On-site treatment to Subsurface', logInflows=True, categories=['Subsurface', 'Subsurface_T', 'Transformed'])
EndOnSiteTreat_Subsurface_M = cp.Sink('Matrix-embedded from End of On-site treatment to Subsurface', logInflows=True, categories=['Subsurface', 'Subsurface_M', 'Matrix-embedded'])

# Definition of the sludge that stays on site
OnsiteSludge_M = cp.Sink('Matrix-embedded in OnsiteSludge', logInflows=True, categories=['OnsiteSludge', 'OnsiteSludge_M', 'Matrix-embedded'])
OnsiteSludge_T = cp.Sink('Transformed in OnsiteSludge', logInflows=True, categories=['OnsiteSludge', 'OnsiteSludge_T', 'Transformed'])


# In[16]:


# Definition of Reprocessing

# Reprocessing of mineral waste from CDW
Reprocess_Mineral_P=cp.FlowCompartment('Mineral waste to reprocess as product-embedded forms',logInflows=True, logOutflows=True, categories=['Reprocessing', 'Reprocess_P', 'Reprocessed Minerals'])
Air_Mineral= cp.FlowCompartment('ENM particles in Air from crushing minerals', logInflows=True,logOutflows=True, categories=['Air'])

# Forms of NMs in air after reprocessing
Air_NM = cp.FlowCompartment('N and M particles in air from Reprocessing',logInflows=True,logOutflows=True, categories=['Air_NM'])

# Definition of RPAir in order to sum up flows to air from reprocessing
RPAir_N= cp.Sink('Pristine particles in air from reprocessing systems',logInflows=True, categories=['Air_N','Pristine'])
RPAir_M= cp.Sink('Matrix-embedded particles in air from reprocessing systems',logInflows=True, categories=['Air_M','Matrix-embedded'])
RPAir_T= cp.Sink('Transformed particles in air from reprocessing systems',logInflows=True,categories=['Air_T','Transformed'])

# Definition of reuse compartments to store all final products from recycling factories
Manuf_Reuse_P = cp.Sink('Product-embedded waste from Manufacturing to Reuse', logInflows=True, categories=['Reuse', 'Reuse_P'])
SortCDWMiner_Reuse_P = cp.Sink('Product-embedded from Sorted Minerals to Reuse', logInflows=True, categories=['Reuse', 'Reuse_P'])
Filterash_Reuse_N = cp.Sink('Pristine from Filter ash to Reuse', logInflows=True, categories=['Reuse', 'Reuse_N'])
Filterash_Reuse_T = cp.Sink('Transformed from Filter ash to Reuse', logInflows=True, categories=['Reuse', 'Reuse_T'])
Bottomash_Reuse_N = cp.Sink('Pristine from Bottom ash to Reuse', logInflows=True, categories=['Reuse', 'Reuse_N'])
Bottomash_Reuse_T = cp.Sink('Transformed from Bottom ash to Reuse', logInflows=True, categories=['Reuse', 'Reuse_T'])


# In[17]:


compartmentList = [Inflow_Prod, Import_Manuf, Import_Cons,
                   Production, 
                   Prod_Air_N, 
                   Manufacture, 
                   Manuf_Air_N,
                   Manuf_Antibact, Manuf_Liquids,
                   Manuf_Antibact_Waste, manuf_textiles_waste, manuf_plastics_waste,
                   Consumption,
                   PersCare, PersCare_Use, PersCare_EoL,
                   PainLacq, PainLacq_Use, PainLacq_EoL,
                   Antibact, Antibact_Use, Antibact_EoL,
                                      
                   PersCare_WW, PersCare_WW_D, PersCare_WW_N, 
                   PersCare_SW, PersCare_SW_D, PersCare_SW_N,
                   PainLacq_WW, PainLacq_WW_N, PainLacq_WW_M, PainLacq_WW_D, PainLacq_WW_T,
                   PainLacq_NUsoil, PainLacq_NUsoil_N, PainLacq_NUsoil_M, PainLacq_NUsoil_D, PainLacq_NUsoil_T,
                   PainLacq_Air, PainLacq_Air_M,
                   Antibact_WW, Antibact_WW_N, Antibact_WW_M, Antibact_WW_T, Antibact_WW_D,
                   Antibact_Air, Antibact_Air_N, Antibact_Air_M,
                   
                   WIP_M, WIP_T, WIP_P,
                   Burning_N, Burning_T,
                   Bottomash_N, Bottomash_T, Flyash_N, Flyash_T, Filterash_N, Filterash_T, Acidwashing_N, Acidwashing_T,
                   WIP_Air_N, WIP_Air_T,

                   WW_N, WW_M, WW_D, WW_T,
                   NoSewageSystem_N, NoSewageSystem_M, NoSewageSystem_T, NoSewageSystem_D,
                   SewageSystem_N, SewageSystem_M, SewageSystem_T, SewageSystem_D,
                   OnSiteTreat_N, OnSiteTreat_M, OnSiteTreat_T, OnSiteTreat_D,
                   EndOfSewer_M, EndOfSewer_T, EndOfSewer_D,  
                   STPoverflow_M, STPoverflow_T, STPoverflow_D, 
                   WWTP_M, WWTP_T, WWTP_D,  
                   TreatI_M, TreatI_T, TreatI_D, 
                   TreatII_M, TreatII_T, TreatII_D, 
                   TreatIII_M, TreatIII_T, TreatIII_D, 
                   TreatIOnsite_N, TreatIOnsite_M, TreatIOnsite_T, TreatIOnsite_D,
                   EndOfTreatI_M, EndOfTreatI_T, 
                   EndOfTreatII_M, EndOfTreatII_T,
                   EndOfTreatIII_M, EndOfTreatIII_T,
                   EndOfTreatIOnsite_N, EndOfTreatIOnsite_M, EndOfTreatIOnsite_T,
                   STPeffluent_M, STPeffluent_T, 
                   STPsludge_M, STPsludge_T, 
                   OnsiteSludge_M, OnsiteSludge_T, 
                   
                   EndSewer_Subsurface_M, EndSewer_Subsurface_T, EndSewer_Subsurface_D,
                   EndOnSiteTreat_Subsurface_M, EndOnSiteTreat_Subsurface_N, EndOnSiteTreat_Subsurface_T,  
                   
                   MMSW, PackW, CDW,
                   Sorting_PackW, Sorting_CDW,
                   Export,
                                      
                   Sorting_CDW_Mineral, Air_Mineral,
                                      
                   Reprocess_Mineral_P,
                   
                   Manuf_Reuse_P, SortCDWMiner_Reuse_P, Filterash_Reuse_N, Filterash_Reuse_T,
                   Bottomash_Reuse_N, Bottomash_Reuse_T,
                   
                   Air_NM, RPAir_N, RPAir_M, RPAir_T,
                                      
                   Manuf_Landfill_P, Slud_Landfill_M, Slud_Landfill_T, MMSW_Landfill_P, 
                   CDW_Landfill_P, SortCDW_Landfill_P, SortCDWMiner_Landfill_P,
                   Filterash_Landfill_N, Filterash_Landfill_T, Bottomash_Landfill_N, Bottomash_Landfill_T,
                   
                   STsoil_T, STsoil_M,
                   
                   NoSew_SurfWater_N, NoSew_SurfWater_M, NoSew_SurfWater_T, NoSew_SurfWater_D,
                   Sew_SurfWater_M, Sew_SurfWater_T, Sew_SurfWater_D,
                   STPoverflow_SurfWater_M, STPoverflow_SurfWater_T, STPoverflow_SurfWater_D,
                   STPeffluent_SurfWater_M, STPeffluent_SurfWater_T]
                  
model.setCompartments(compartmentList)


# In[ ]:


### IMPORT PRODUCTION DATA


# In[18]:


Productiondata = pd.read_csv('nano_ZnO_production2000-2030.csv', header=None)
Productiondata.shape


# In[21]:


# Production for the whole Europe:
Productiondata_EU = Productiondata.values
# Scaling production for Poland only:
Productiondata_POL = Productiondata_EU*0
# Initialising the list to be put in the model:
Productionvolume_EU = []
Productionvolume_POL = []
for i in np.arange(0,31):
    Productionvolume_EU.append(Productiondata_EU[:,i]) 
    Productionvolume_POL.append(Productiondata_POL[:,i])
periodRange = np.arange(0,31)
model.addInflow(cp.ExternalListInflow(Inflow_Prod, [cp.RandomChoiceInflow(Productionvolume_POL[x]) for x in periodRange]))

# Adding imports.
SF_Prod = 0
SF_Manuf = nr.triangular(0.0407*(1-0.2), 0.0407, 0.0407*(1+0.2), 10000)
SF_Cons = nr.triangular(0.0446*(1-0.29), 0.0446, 0.0446*(1+0.29), 10000)
model.addInflow(cp.ExternalListInflow(Import_Manuf, [cp.RandomChoiceInflow((Productionvolume_EU[x])*(SF_Manuf-SF_Prod)) for x in periodRange]))
model.addInflow(cp.ExternalListInflow(Import_Cons, [cp.RandomChoiceInflow((Productionvolume_EU[x])*(SF_Cons-SF_Manuf)) for x in periodRange]))


# In[22]:


# Transfer Coefficients
Inflow_Prod.transfers = [cp.ConstTransfer(1, Production)]
Import_Manuf.transfers = [cp.ConstTransfer(1, Manufacture)]
Import_Cons.transfers = [cp.ConstTransfer(1, Consumption)]


# In[23]:


### Transfers from Production and Manufacture
Production.localRelease = cp.ListRelease([1.0])

Manufacture.localRelease = cp.ListRelease([1.0])  

Production.transfers = [cp.StochasticTransfer(nr.triangular, [0.0002, 0.0125, 0.0467], WW_N, priority=2),
                        cp.StochasticTransfer(nr.triangular, [0.0000008, 0.0000016, 0.0000024], Prod_Air_N, priority=2),
                        cp.ConstTransfer(1, Manufacture, priority=1)]
                      
# Allocate manufactured products to different categories:
Tot_Manuf_Liquids = nr.triangular(0.425, 0.85, 1, 10000) + nr.triangular(0.065, 0.13, 0.195, 10000)

Manufacture.transfers = [cp.RandomChoiceTransfer(Tot_Manuf_Liquids, Manuf_Liquids, priority=2),
                         cp.StochasticTransfer(nr.triangular, [0.01, 0.02, 0.03], Manuf_Antibact, priority=1)]

Manuf_Antibact.transfers = [cp.StochasticTransfer(nr.triangular, [0.00000085, 0.0000017, 0.00000255], Manuf_Air_N, priority=2),
                           cp.StochasticTransfer(nr.uniform, [0.001, 0.0016], WW_N, priority=2),
                           cp.StochasticTransfer(nr.triangular, [0.005, 0.01, 0.015], Manuf_Antibact_Waste, priority=2),
                           cp.ConstTransfer(1, Consumption, priority=1)]
Manuf_Liquids.transfers = [cp.StochasticTransfer(nr.triangular, [0.00000085, 0.0000017, 0.00000255], Manuf_Air_N, priority=2),
                           cp.StochasticTransfer(nr.uniform, [0.001, 0.0016], WW_N, priority=2),
                           cp.ConstTransfer(1, Consumption, priority=1)]


# Antibacterial products are coated on textiles and plastics, but we do not know in which proportions.
# So we attribute 50% of this waste to textile waste and 50% to plastic waste
Manuf_Antibact_Waste.transfers = [cp.StochasticTransfer(nr.uniform, [0, 1], manuf_textiles_waste),
                                 cp.StochasticTransfer(nr.uniform, [0, 1], manuf_plastics_waste)]

manuf_textiles_waste.transfers = [cp.StochasticTransfer(nr.triangular, [0.25, 0.5, 0.75], Manuf_Reuse_P),
                                 cp.StochasticTransfer(nr.triangular, [0.3*0.25, 0.3*0.5, 0.3*0.75], WIP_P),
                                 cp.StochasticTransfer(nr.triangular, [0.7*0.25, 0.7*0.5, 0.7*0.75], Manuf_Landfill_P)]
manuf_plastics_waste.transfers = [cp.RandomChoiceTransfer(tf.TriangTruncDet(0.455, 0.91, 1.365, 10000, 0, 1), Manuf_Reuse_P),
                                 cp.StochasticTransfer(nr.triangular, [0.045, 0.09, 0.135], WIP_P),
                                 cp.StochasticTransfer(nr.triangular, [0.001, 0.002, 0.003], Manuf_Landfill_P)]


# In[24]:


# ENM allocation to product categories
Consumption.transfers = [cp.StochasticTransfer(nr.triangular, [0.425, 0.85, 1], PersCare),
                         cp.StochasticTransfer(nr.triangular, [0.065, 0.13, 0.195], PainLacq),
                         cp.StochasticTransfer(nr.triangular, [0.01, 0.02, 0.03], Antibact)]


# In[25]:


# Product categories to their USE and EoL compartments
PersCare.transfers = [cp.ConstTransfer(1, PersCare_Use, priority=1),
                      cp.StochasticTransfer(nr.triangular, [0.025, 0.05, 0.075], PersCare_EoL, priority=2)]

PainLacq.transfers = [cp.ConstTransfer(1, PainLacq_EoL, priority=1),
                      cp.StochasticTransfer(nr.triangular, [0.175, 0.35, 0.525], PainLacq_Use, priority=2)]

Antibact.transfers = [cp.StochasticTransfer(nr.triangular, [0.3, 0.6, 0.9], Antibact_Use, priority=2),
                      cp.ConstTransfer(1, Antibact_EoL, priority=1)] 


# In[27]:


# Transfers from Personal care
PersCare_Use.localRelease = cp.ListRelease([0.90,0.10])

PersCare_EoL.localRelease = cp.ListRelease([0.90,0.10]) 

PersCare_Use.transfers = [cp.ConstTransfer(1, PersCare_WW, priority=1),
                          cp.StochasticTransfer(nr.triangular, [0.05,0.10,0.15], PersCare_SW, priority=2)]

PersCare_WW.transfers = [cp.StochasticTransfer(nr.triangular, [0.005, 0.01, 0.015], PersCare_WW_D, priority=2),
                         cp.ConstTransfer(1, PersCare_WW_N, priority=1)]
PersCare_SW.transfers = [cp.StochasticTransfer(nr.triangular, [0.005, 0.01, 0.015], PersCare_SW_D, priority=2),
                         cp.ConstTransfer(1, PersCare_SW_N, priority=1)]

PersCare_EoL.transfers = [cp.ConstTransfer(1, PackW, priority=1)]


# In[28]:


# Transfers from Paints & lacquers                         
PainLacq_Use.localRelease = cp.ListRelease([0.9,0.01666667,0.01666667,0.01666667,0.01666667,
                                            0.01666667,0.01666667])

PainLacq_EoL.localRelease = cp.ListRelease([0,0,0,0,0,0,0,0,0,0,
                                          0,0,0,0,0,0,0,0,0,0,
                                          0,0,0,0,0,0,0,0,0,0,
                                          0,0,0,0,0,0,0,0,0,0,
                                          0,0,0,0,0,0,0,0,0,0,
                                          0,0,0,0,0,0,0,0,0,0.001722281,
                                          0.001037804,0.001572363,0.00232936,0.003374171,0.004779078,
                                          0.006618624,0.00896268,0.01186737,0.01536449,0.01945038,
                                          0.02407602,0.0291399,0.03448561,0.03990567,0.04515209,
                                          0.04995371,0.05403864,0.0571594,0.05911772,0.05978529, 
                                          0.05911772,0.0571594,0.05403864,0.04995371,0.04515209,
                                          0.03990567,0.03448561,0.0291399,0.02407602,0.01945038,
                                          0.01536449,0.01186737,0.00896268,0.006618624,0.004779078,
                                          0.003374171,0.00232936,0.001572363,0.001037804,0.001722281]) 

PainLacq_Use.transfers = [cp.StochasticTransfer(nr.triangular, [0.25, 0.50, 0.75], PainLacq_WW, priority=1),
                          cp.StochasticTransfer(nr.triangular, [0.125, 0.25, 0.375], PainLacq_Air, priority=1),
                          cp.StochasticTransfer(nr.triangular, [0.125, 0.25, 0.375], PainLacq_NUsoil, priority=1)]

PainLacq_WW.transfers = [cp.StochasticTransfer(nr.uniform, [0.01, 0.1], PainLacq_WW_N, priority=1),
                         cp.StochasticTransfer(nr.uniform, [0.01, 0.1], PainLacq_WW_T, priority=1),
                         cp.StochasticTransfer(nr.uniform, [0, 1], PainLacq_WW_D, priority=1),
                         cp.StochasticTransfer(nr.uniform, [0, 1], PainLacq_WW_M, priority=1)]

PainLacq_NUsoil.transfers = [cp.StochasticTransfer(nr.uniform, [0.01, 0.1], PainLacq_NUsoil_N, priority=1),
                             cp.StochasticTransfer(nr.uniform, [0.01, 0.1], PainLacq_NUsoil_T, priority=1),
                             cp.StochasticTransfer(nr.uniform, [0, 1], PainLacq_NUsoil_D, priority=1),
                             cp.StochasticTransfer(nr.uniform, [0, 1], PainLacq_NUsoil_M, priority=1)]

PainLacq_Air.transfers = [cp.ConstTransfer(1, PainLacq_Air_M, priority=1)]

PainLacq_EoL.transfers = [cp.StochasticTransfer(tf.TriangTruncDet, [0.475, 0.95, 1.425, 1, 0, 1], CDW, priority=1),
                          cp.StochasticTransfer(nr.triangular, [0.025, 0.05, 0.075], MMSW, priority=1)]


# In[29]:


# Transfers from Antibacterial
# For lifetime releases, and releases during use, textiles in Sun et al. 2016 are taken as a proxy

Antibact_Use.localRelease = cp.ListRelease([0.5,0.3,0.2])

Antibact_EoL.localRelease = cp.ListRelease([0.01222447,0.2144029,0.5467453,0.2144029,0.01222447]) 

Antibact_Use.transfers = [cp.StochasticTransfer(nr.triangular, [0.4, 0.8, 1], Antibact_WW, priority=2),
                          cp.ConstTransfer(1, Antibact_Air, priority=2)]

Antibact_WW.transfers = [cp.StochasticTransfer(nr.uniform, [0, 1], Antibact_WW_N, priority=1),
                        cp.StochasticTransfer(nr.uniform, [0, 1], Antibact_WW_M, priority=1),
                        cp.StochasticTransfer(nr.uniform, [0, 1], Antibact_WW_T, priority=1),
                        cp.StochasticTransfer(nr.uniform, [0, 1], Antibact_WW_D, priority=1)]

Antibact_Air.transfers = [cp.StochasticTransfer(nr.triangular, [0.495, 0.99, 1], Antibact_Air_M, priority=1),
                         cp.StochasticTransfer(nr.triangular, [0.005, 0.01, 0.015], Antibact_Air_N, priority=1)] # Same as Ag in textiles

Antibact_EoL.transfers = [cp.ConstTransfer(1, MMSW, priority=1)]


# In[30]:


s = 10000   #sampling size used for sampling in uncertainty ranges of several sources/values


# In[32]:


### Gather all flows to wastewater
PersCare_WW_D.transfers = [cp.ConstTransfer(1, WW_D, priority=1)]
PersCare_WW_N.transfers = [cp.ConstTransfer(1, WW_N, priority=1)]

PainLacq_WW_D.transfers = [cp.ConstTransfer(1, WW_D, priority=1)]
PainLacq_WW_N.transfers = [cp.ConstTransfer(1, WW_N, priority=1)]
PainLacq_WW_M.transfers = [cp.ConstTransfer(1, WW_M, priority=1)]
PainLacq_WW_T.transfers = [cp.ConstTransfer(1, WW_T, priority=1)]

Antibact_WW_N.transfers = [cp.ConstTransfer(1, WW_N, priority=1)]
Antibact_WW_M.transfers = [cp.ConstTransfer(1, WW_M, priority=1)]
Antibact_WW_T.transfers = [cp.ConstTransfer(1, WW_T, priority=1)]
Antibact_WW_D.transfers = [cp.ConstTransfer(1, WW_D, priority=1)]


# In[ ]:


### WASTEWATER MANAGEMENT


# In[33]:


# Transfers of Wastewater to no sewage system
WW_NS_y0 = cp.TransferDistribution(nr.triangular, [0.0815, 0.163, 0.2445])
WW_NS_y1 = cp.TransferDistribution(nr.triangular, [0.075, 0.15, 0.225])
WW_NS_y2 = cp.TransferDistribution(nr.triangular, [0.0775, 0.155, 0.2325])
WW_NS_y3 = cp.TransferDistribution(nr.triangular, [0.0765, 0.153, 0.2295])
WW_NS_y4 = cp.TransferDistribution(nr.triangular, [0.076, 0.152, 0.228])
WW_NS_y5 = cp.TransferDistribution(nr.triangular, [0.0785, 0.157, 0.2355])
WW_NS_y6 = cp.TransferDistribution(nr.triangular, [0.067, 0.134, 0.201])
WW_NS_y7 = cp.TransferDistribution(nr.triangular, [0.0715, 0.143, 0.2145])
WW_NS_y8 = cp.TransferDistribution(nr.triangular, [0.071, 0.142, 0.213])
WW_NS_y9 = cp.TransferDistribution(nr.triangular, [0.072, 0.144, 0.216])
WW_NS_y10 = cp.TransferDistribution(nr.triangular, [0.0715, 0.143, 0.2145])
WW_NS_y11 = cp.TransferDistribution(nr.triangular, [0.074, 0.148, 0.222])
WW_NS_y12 = cp.TransferDistribution(nr.triangular, [0.0725, 0.145, 0.2175])
WW_NS_y13 = cp.TransferDistribution(nr.triangular, [0.072, 0.144, 0.216])
WW_NS_y14 = cp.TransferDistribution(nr.triangular, [0.071, 0.142, 0.213])
WW_NS_y15 = cp.TransferDistribution(nr.triangular, [0.0715, 0.143, 0.2145])
WW_NS_y16 = cp.TransferDistribution(nr.triangular, [0.0715, 0.143, 0.2145])
WW_NS_y17 = cp.TransferDistribution(nr.triangular, [0.0715, 0.143, 0.2145])
WW_NS_y18 = cp.TransferDistribution(nr.triangular, [0.0715, 0.143, 0.2145])
WW_NS_y19 = cp.TransferDistribution(nr.triangular, [0.0715, 0.143, 0.2145])
WW_NS_y20 = cp.TransferDistribution(nr.triangular, [0.072, 0.144, 0.216])

WW_N.transfers = [cp.TimeDependendDistributionTransfer([WW_NS_y0,
                                                        WW_NS_y1,WW_NS_y2,WW_NS_y3,WW_NS_y4,WW_NS_y5,
                                                        WW_NS_y6,WW_NS_y7,WW_NS_y8,WW_NS_y9,WW_NS_y10,
                                                        WW_NS_y11,WW_NS_y12,WW_NS_y13,WW_NS_y14,WW_NS_y15,
                                                        WW_NS_y16,WW_NS_y17,WW_NS_y18,WW_NS_y19,WW_NS_y20],
                                                       NoSewageSystem_N, WW_N, priority=2), 
                  cp.ConstTransfer(1, SewageSystem_N, priority=1)]
WW_M.transfers = [cp.TimeDependendDistributionTransfer([WW_NS_y0,
                                                        WW_NS_y1,WW_NS_y2,WW_NS_y3,WW_NS_y4,WW_NS_y5,
                                                        WW_NS_y6,WW_NS_y7,WW_NS_y8,WW_NS_y9,WW_NS_y10,
                                                        WW_NS_y11,WW_NS_y12,WW_NS_y13,WW_NS_y14,WW_NS_y15,
                                                        WW_NS_y16,WW_NS_y17,WW_NS_y18,WW_NS_y19,WW_NS_y20],
                                                       NoSewageSystem_M, WW_M, priority=2), 
                  cp.ConstTransfer(1, SewageSystem_M, priority=1)]
WW_T.transfers = [cp.TimeDependendDistributionTransfer([WW_NS_y0,
                                                        WW_NS_y1,WW_NS_y2,WW_NS_y3,WW_NS_y4,WW_NS_y5,
                                                        WW_NS_y6,WW_NS_y7,WW_NS_y8,WW_NS_y9,WW_NS_y10,
                                                        WW_NS_y11,WW_NS_y12,WW_NS_y13,WW_NS_y14,WW_NS_y15,
                                                        WW_NS_y16,WW_NS_y17,WW_NS_y18,WW_NS_y19,WW_NS_y20],
                                                       NoSewageSystem_T, WW_T, priority=2), 
                  cp.ConstTransfer(1, SewageSystem_T, priority=1)]
WW_D.transfers = [cp.TimeDependendDistributionTransfer([WW_NS_y0,
                                                        WW_NS_y1,WW_NS_y2,WW_NS_y3,WW_NS_y4,WW_NS_y5,
                                                        WW_NS_y6,WW_NS_y7,WW_NS_y8,WW_NS_y9,WW_NS_y10,
                                                        WW_NS_y11,WW_NS_y12,WW_NS_y13,WW_NS_y14,WW_NS_y15,
                                                        WW_NS_y16,WW_NS_y17,WW_NS_y18,WW_NS_y19,WW_NS_y20],
                                                       NoSewageSystem_D, WW_D, priority=2), 
                        cp.ConstTransfer(1, SewageSystem_D, priority=1)]

# Transfers from no sewer
NoSewageSystem_N.transfers = [cp.ConstTransfer(0.03, NoSew_SurfWater_N, priority=1),   
                              cp.ConstTransfer(0.11, OnSiteTreat_N, priority=1)]
NoSewageSystem_M.transfers = [cp.ConstTransfer(0.03, NoSew_SurfWater_M, priority=1),   
                              cp.ConstTransfer(0.11, OnSiteTreat_M, priority=1)]
NoSewageSystem_T.transfers = [cp.ConstTransfer(0.03, NoSew_SurfWater_T, priority=1),   
                              cp.ConstTransfer(0.11, OnSiteTreat_T, priority=1)]
NoSewageSystem_D.transfers = [cp.ConstTransfer(0.03, NoSew_SurfWater_D, priority=1),   
                              cp.ConstTransfer(0.11, OnSiteTreat_D, priority=1)]

# Transfers from on-site treatment
OnSiteTreat_N.transfers = [cp.ConstTransfer(1, TreatIOnsite_N, priority=1)]
OnSiteTreat_M.transfers = [cp.ConstTransfer(1, TreatIOnsite_M, priority=1)]
OnSiteTreat_T.transfers = [cp.ConstTransfer(1, TreatIOnsite_T, priority=1)]
OnSiteTreat_D.transfers = [cp.ConstTransfer(1, TreatIOnsite_D, priority=1)]


# In[34]:


# Transformations in sewage system                     
SewageSystem_N.transfers = [cp.ConstTransfer(1, EndOfSewer_T, priority=1)]
SewageSystem_M.transfers = [cp.ConstTransfer(1, EndOfSewer_M, priority=1)]
SewageSystem_T.transfers = [cp.ConstTransfer(1, EndOfSewer_T, priority=1)]
SewageSystem_D.transfers = [cp.ConstTransfer(1, EndOfSewer_D, priority=1)]


# In[35]:


# Transfers from sewage system 
# to surface water (non-treated water, NT)
SS_NT_y0 = cp.TransferDistribution(nr.triangular, [0.0325, 0.065, 0.0975])
SS_NT_y1 = cp.TransferDistribution(nr.triangular, [0.034, 0.068, 0.102])
SS_NT_y2 = cp.TransferDistribution(nr.triangular, [0.028, 0.056, 0.084])
SS_NT_y3 = cp.TransferDistribution(nr.triangular, [0.0245, 0.049, 0.0735])
SS_NT_y4 = cp.TransferDistribution(nr.triangular, [0.0225, 0.045, 0.0675])
SS_NT_y5 = cp.TransferDistribution(nr.triangular, [0.018, 0.036, 0.054])
SS_NT_y6 = cp.TransferDistribution(nr.triangular, [0.0285, 0.057, 0.0855])
SS_NT_y7 = cp.TransferDistribution(nr.triangular, [0.024, 0.048, 0.072])
SS_NT_y8 = cp.TransferDistribution(nr.triangular, [0.0235, 0.047, 0.0705])
SS_NT_y9 = cp.TransferDistribution(nr.triangular, [0.0205, 0.041, 0.0615])
SS_NT_y10 = cp.TransferDistribution(nr.triangular, [0.0185, 0.037, 0.0555])
SS_NT_y11 = cp.TransferDistribution(nr.triangular, [0.016, 0.032, 0.048])
SS_NT_y12 = cp.TransferDistribution(nr.triangular, [0.014, 0.028, 0.042])
SS_NT_y13 = cp.TransferDistribution(nr.triangular, [0.0125, 0.025, 0.0375])
SS_NT_y14 = cp.TransferDistribution(nr.triangular, [0.0105, 0.021, 0.0315])
SS_NT_y15 = cp.TransferDistribution(nr.triangular, [0.0085, 0.017, 0.0255])
SS_NT_y16 = cp.TransferDistribution(nr.triangular, [0.007, 0.014, 0.021])
SS_NT_y17 = cp.TransferDistribution(nr.triangular, [0.005, 0.01, 0.015])
SS_NT_y18 = cp.TransferDistribution(nr.triangular, [0.0035, 0.007, 0.0105])
SS_NT_y19 = cp.TransferDistribution(nr.triangular, [0.00152318181818182, 0.003, 0.00447681818181818])
SS_NT_y20 = cp.TransferConstant(0)

EndOfSewer_M.transfers= [cp.StochasticTransfer(nr.triangular, [0.016, 0.032, 0.048], STPoverflow_M, priority=2),  # Overflow rate
                         cp.StochasticTransfer(nr.triangular, [0.0325, 0.065, 0.0975], EndSewer_Subsurface_M, priority=2), # Exfiltration
                         cp.TimeDependendDistributionTransfer([SS_NT_y0,
                                                              SS_NT_y1,SS_NT_y2,SS_NT_y3,SS_NT_y4,SS_NT_y5,
                                                              SS_NT_y6,SS_NT_y7,SS_NT_y8,SS_NT_y9,SS_NT_y10,
                                                              SS_NT_y11,SS_NT_y12,SS_NT_y13,SS_NT_y14,SS_NT_y15,
                                                              SS_NT_y16,SS_NT_y17,SS_NT_y18,SS_NT_y19,SS_NT_y20],
                                                              Sew_SurfWater_M, SewageSystem_M, priority=2), #discharges of sewer to nature (when no wwtp is installed)
                         cp.ConstTransfer(1, WWTP_M, priority=1)]
EndOfSewer_T.transfers= [cp.StochasticTransfer(nr.triangular, [0.016, 0.032, 0.048], STPoverflow_T, priority=2),  # Overflow rate
                         cp.StochasticTransfer(nr.triangular, [0.0325, 0.065, 0.0975], EndSewer_Subsurface_T, priority=2), # Exfiltration
                         cp.TimeDependendDistributionTransfer([SS_NT_y0,
                                                              SS_NT_y1,SS_NT_y2,SS_NT_y3,SS_NT_y4,SS_NT_y5,
                                                              SS_NT_y6,SS_NT_y7,SS_NT_y8,SS_NT_y9,SS_NT_y10,
                                                              SS_NT_y11,SS_NT_y12,SS_NT_y13,SS_NT_y14,SS_NT_y15,
                                                              SS_NT_y16,SS_NT_y17,SS_NT_y18,SS_NT_y19,SS_NT_y20],
                                                              Sew_SurfWater_T, SewageSystem_T, priority=2), #discharges of sewer to nature (when no wwtp is installed)
                         cp.ConstTransfer(1, WWTP_T, priority=1)]
EndOfSewer_D.transfers= [cp.StochasticTransfer(nr.triangular, [0.016, 0.032, 0.048], STPoverflow_D, priority=2),  # Overflow rate
                         cp.StochasticTransfer(nr.triangular, [0.0325, 0.065, 0.0975], EndSewer_Subsurface_D, priority=2), # Exfiltration
                         cp.TimeDependendDistributionTransfer([SS_NT_y0,
                                                              SS_NT_y1,SS_NT_y2,SS_NT_y3,SS_NT_y4,SS_NT_y5,
                                                              SS_NT_y6,SS_NT_y7,SS_NT_y8,SS_NT_y9,SS_NT_y10,
                                                              SS_NT_y11,SS_NT_y12,SS_NT_y13,SS_NT_y14,SS_NT_y15,
                                                              SS_NT_y16,SS_NT_y17,SS_NT_y18,SS_NT_y19,SS_NT_y20],
                                                              Sew_SurfWater_D, SewageSystem_D, priority=2), #discharges of sewer to nature (when no wwtp is installed)
                         cp.ConstTransfer(1, WWTP_D, priority=1)]


# In[36]:


# Levels of treatment in WWTP
WWTP_TI_y0 = cp.TransferDistribution(nr.triangular, [0.0295, 0.059, 0.0885])
WWTP_TI_y1 = cp.TransferDistribution(nr.triangular, [0.0255, 0.051, 0.0765])
WWTP_TI_y2 = cp.TransferDistribution(nr.triangular, [0.021, 0.042, 0.063])
WWTP_TI_y3 = cp.TransferDistribution(nr.triangular, [0.0175, 0.035, 0.0525])
WWTP_TI_y4 = cp.TransferDistribution(nr.triangular, [0.014, 0.028, 0.042])
WWTP_TI_y5 = cp.TransferDistribution(nr.triangular, [0.011, 0.022, 0.033])
WWTP_TI_y6 = cp.TransferDistribution(nr.triangular, [0.012, 0.024, 0.036])
WWTP_TI_y7 = cp.TransferDistribution(nr.triangular, [0.0105, 0.021, 0.0315])
WWTP_TI_y8 = cp.TransferDistribution(nr.triangular, [0.011, 0.022, 0.033])
WWTP_TI_y9 = cp.TransferDistribution(nr.triangular, [0.008, 0.016, 0.024])
WWTP_TI_y10 = cp.TransferDistribution(nr.triangular, [0.0075, 0.015, 0.0225])
WWTP_TI_y11 = cp.TransferDistribution(nr.triangular, [0.0065, 0.013, 0.0195])
WWTP_TI_y12 = cp.TransferDistribution(nr.triangular, [0.0055, 0.011, 0.0165])
WWTP_TI_y13 = cp.TransferDistribution(nr.triangular, [0.005, 0.01, 0.015])
WWTP_TI_y14 = cp.TransferDistribution(nr.triangular, [0.004, 0.008, 0.012])
WWTP_TI_y15 = cp.TransferDistribution(nr.triangular, [0.0035, 0.007, 0.0105])
WWTP_TI_y16 = cp.TransferDistribution(nr.triangular, [0.0025, 0.005, 0.0075])
WWTP_TI_y17 = cp.TransferDistribution(nr.triangular, [0.002, 0.004, 0.006])
WWTP_TI_y18 = cp.TransferDistribution(nr.triangular, [0.0015, 0.003, 0.0045])
WWTP_TI_y19 = cp.TransferDistribution(nr.triangular, [0.0005, 0.001, 0.0015])
WWTP_TI_y20 = cp.TransferConstant(0)

WWTP_TII_y0 = cp.TransferDistribution(nr.triangular, [0.1725, 0.345, 0.5175])
WWTP_TII_y1 = cp.TransferDistribution(nr.triangular, [0.1615, 0.323, 0.4845])
WWTP_TII_y2 = cp.TransferDistribution(nr.triangular, [0.161, 0.322, 0.483])
WWTP_TII_y3 = cp.TransferDistribution(nr.triangular, [0.1535, 0.307, 0.4605])
WWTP_TII_y4 = cp.TransferDistribution(nr.triangular, [0.145, 0.29, 0.435])
WWTP_TII_y5 = cp.TransferDistribution(nr.triangular, [0.123, 0.246, 0.369])
WWTP_TII_y6 = cp.TransferDistribution(nr.triangular, [0.1305, 0.261, 0.3915])
WWTP_TII_y7 = cp.TransferDistribution(nr.triangular, [0.124, 0.248, 0.372])
WWTP_TII_y8 = cp.TransferDistribution(nr.triangular, [0.118, 0.236, 0.354])
WWTP_TII_y9 = cp.TransferDistribution(nr.triangular, [0.1125, 0.225, 0.3375])
WWTP_TII_y10 = cp.TransferDistribution(nr.triangular, [0.108, 0.216, 0.324])
WWTP_TII_y11 = cp.TransferDistribution(nr.triangular, [0.105, 0.21, 0.315])
WWTP_TII_y12 = cp.TransferDistribution(nr.triangular, [0.1025, 0.205, 0.3075])
WWTP_TII_y13 = cp.TransferDistribution(nr.triangular, [0.0975, 0.195, 0.2925])
WWTP_TII_y14 = cp.TransferDistribution(nr.triangular, [0.0925, 0.185, 0.2775])
WWTP_TII_y15 = cp.TransferDistribution(nr.triangular, [0.0875, 0.175, 0.2625])
WWTP_TII_y16 = cp.TransferDistribution(nr.triangular, [0.083, 0.166, 0.249])
WWTP_TII_y17 = cp.TransferDistribution(nr.triangular, [0.0785, 0.157, 0.2355])
WWTP_TII_y18 = cp.TransferDistribution(nr.triangular, [0.074, 0.148, 0.222])
WWTP_TII_y19 = cp.TransferDistribution(nr.triangular, [0.0706, 0.139, 0.2074])
WWTP_TII_y20 = cp.TransferDistribution(nr.triangular, [0.060931, 0.109, 0.157069])

WWTP_M.transfers = [cp.TimeDependendDistributionTransfer([WWTP_TI_y0,
                                                          WWTP_TI_y1,WWTP_TI_y2,WWTP_TI_y3,WWTP_TI_y4,WWTP_TI_y5,
                                                          WWTP_TI_y6,WWTP_TI_y7,WWTP_TI_y8,WWTP_TI_y9,WWTP_TI_y10,
                                                          WWTP_TI_y11,WWTP_TI_y12,WWTP_TI_y13,WWTP_TI_y14,WWTP_TI_y15,
                                                          WWTP_TI_y16,WWTP_TI_y17,WWTP_TI_y18,WWTP_TI_y19,WWTP_TI_y20],
                                                         TreatI_M, WWTP_M, priority=2),
                    cp.TimeDependendDistributionTransfer([WWTP_TII_y0,
                                                          WWTP_TII_y1,WWTP_TII_y2,WWTP_TII_y3,WWTP_TII_y4,WWTP_TII_y5,
                                                          WWTP_TII_y6,WWTP_TII_y7,WWTP_TII_y8,WWTP_TII_y9,WWTP_TII_y10,
                                                          WWTP_TII_y11,WWTP_TII_y12,WWTP_TII_y13,WWTP_TII_y14,WWTP_TII_y15,
                                                          WWTP_TII_y16,WWTP_TII_y17,WWTP_TII_y18,WWTP_TII_y19,WWTP_TII_y20],
                                                         TreatII_M, WWTP_M, priority=2),
                    cp.ConstTransfer(1, TreatIII_M, priority =1),]
WWTP_T.transfers = [cp.TimeDependendDistributionTransfer([WWTP_TI_y0,
                                                          WWTP_TI_y1,WWTP_TI_y2,WWTP_TI_y3,WWTP_TI_y4,WWTP_TI_y5,
                                                          WWTP_TI_y6,WWTP_TI_y7,WWTP_TI_y8,WWTP_TI_y9,WWTP_TI_y10,
                                                          WWTP_TI_y11,WWTP_TI_y12,WWTP_TI_y13,WWTP_TI_y14,WWTP_TI_y15,
                                                          WWTP_TI_y16,WWTP_TI_y17,WWTP_TI_y18,WWTP_TI_y19,WWTP_TI_y20],
                                                         TreatI_T, WWTP_T, priority=2),
                    cp.TimeDependendDistributionTransfer([WWTP_TII_y0,
                                                          WWTP_TII_y1,WWTP_TII_y2,WWTP_TII_y3,WWTP_TII_y4,WWTP_TII_y5,
                                                          WWTP_TII_y6,WWTP_TII_y7,WWTP_TII_y8,WWTP_TII_y9,WWTP_TII_y10,
                                                          WWTP_TII_y11,WWTP_TII_y12,WWTP_TII_y13,WWTP_TII_y14,WWTP_TII_y15,
                                                          WWTP_TII_y16,WWTP_TII_y17,WWTP_TII_y18,WWTP_TII_y19,WWTP_TII_y20],
                                                         TreatII_T, WWTP_T, priority=2),
                    cp.ConstTransfer(1, TreatIII_T, priority =1),]
WWTP_D.transfers = [cp.TimeDependendDistributionTransfer([WWTP_TI_y0,
                                                          WWTP_TI_y1,WWTP_TI_y2,WWTP_TI_y3,WWTP_TI_y4,WWTP_TI_y5,
                                                          WWTP_TI_y6,WWTP_TI_y7,WWTP_TI_y8,WWTP_TI_y9,WWTP_TI_y10,
                                                          WWTP_TI_y11,WWTP_TI_y12,WWTP_TI_y13,WWTP_TI_y14,WWTP_TI_y15,
                                                          WWTP_TI_y16,WWTP_TI_y17,WWTP_TI_y18,WWTP_TI_y19,WWTP_TI_y20],
                                                         TreatI_D, WWTP_D, priority=2),
                    cp.TimeDependendDistributionTransfer([WWTP_TII_y0,
                                                          WWTP_TII_y1,WWTP_TII_y2,WWTP_TII_y3,WWTP_TII_y4,WWTP_TII_y5,
                                                          WWTP_TII_y6,WWTP_TII_y7,WWTP_TII_y8,WWTP_TII_y9,WWTP_TII_y10,
                                                          WWTP_TII_y11,WWTP_TII_y12,WWTP_TII_y13,WWTP_TII_y14,WWTP_TII_y15,
                                                          WWTP_TII_y16,WWTP_TII_y17,WWTP_TII_y18,WWTP_TII_y19,WWTP_TII_y20],
                                                         TreatII_D, WWTP_D, priority=2),
                    cp.ConstTransfer(1, TreatIII_D, priority =1),]


# In[37]:


# Transfers of STP overflow to Surface water
STPoverflow_M.transfers = [cp.ConstTransfer(1, STPoverflow_SurfWater_M, priority=1)]
STPoverflow_T.transfers = [cp.ConstTransfer(1, STPoverflow_SurfWater_T, priority=1)]
STPoverflow_D.transfers = [cp.ConstTransfer(1, STPoverflow_SurfWater_D, priority=1)]


# In[38]:


## Transfers from primary treatment and on-site treatment

# Transformations
TreatI_M.transfers = [cp.ConstTransfer(1, EndOfTreatI_M, priority=1)]
TreatI_T.transfers = [cp.ConstTransfer(1, EndOfTreatI_T, priority=1)]
TreatI_D.transfers = [cp.ConstTransfer(1, EndOfTreatI_T, priority=1)]

# From primary treatment to sludge
EndOfTreatI_T.transfers= [cp.StochasticTransfer(nr.triangular, [0.21, 0.3, 0.39], STPeffluent_T, priority=2), 
                          cp.ConstTransfer(1, STPsludge_T, priority=1)]

# We make the assumption that matrix-embedded ENMs behave as microplastics in WWTP, since they have about the same size.
# Three sources are available that studied the removal of MPs after primary treatment in Europe:
# Murphy et al. 2016: 78.34% go to sludge, with a coefficient of variation of 8%.
# Talvitie et al. 2015: from their data, we build a triangular distribution with min of 25.8%, mode of 50% and max of 92.5%.
# Lares et al. 2018: from their data, we build a triangular distribution with min of 91.9%, mode of 99% and max of 99%.
Removal_Murphy = nr.triangular(0.7834*(1-0.08), 0.7834, 0.7834*(1+0.08), 3333)
Removal_Talvitie = nr.triangular(0.258, 0.5, 0.925, 3333)
Removal_Lares = nr.triangular(0.919, 0.99, 0.99, 3333)
RemovalData_TreatI_M = np.concatenate([Removal_Murphy, Removal_Talvitie, Removal_Lares])

EndOfTreatI_M.transfers = [cp.RandomChoiceTransfer(RemovalData_TreatI_M, STPsludge_M, priority=2),
                           cp.ConstTransfer(1, STPeffluent_M, priority=1)]

# From on-site treatment
# Transformation
TreatIOnsite_N.transfers = [cp.StochasticTransfer(tf.TriangTrunc, [0.99, 0.5, 1, 0, 1], EndOfTreatIOnsite_T, priority=2), # same removal data as for TreatI
                          cp.ConstTransfer(1, EndOfTreatIOnsite_N, priority=1)]
TreatIOnsite_M.transfers = [cp.ConstTransfer(1, EndOfTreatIOnsite_M, priority=1)]
TreatIOnsite_T.transfers = [cp.ConstTransfer(1, EndOfTreatIOnsite_T, priority=1)]
TreatIOnsite_D.transfers = [cp.ConstTransfer(1, EndOfTreatIOnsite_T, priority=1)]

# From on-site treatment to sludge
EndOfTreatIOnsite_N.transfers = [cp.StochasticTransfer(nr.triangular, [0.21, 0.3, 0.39], EndOnSiteTreat_Subsurface_N, priority=2),
                                 cp.ConstTransfer(1, OnsiteSludge_T, priority=1)]
EndOfTreatIOnsite_T.transfers = [cp.StochasticTransfer(nr.triangular, [0.21, 0.3, 0.39], EndOnSiteTreat_Subsurface_T, priority=2),
                                 cp.ConstTransfer(1, OnsiteSludge_T, priority=1)]
EndOfTreatIOnsite_M.transfers = [cp.RandomChoiceTransfer(RemovalData_TreatI_M, OnsiteSludge_M, priority=2),
                                 cp.ConstTransfer(1, EndOnSiteTreat_Subsurface_M, priority=1)]


# In[39]:


## Transfers from secondary treatment

# Transformation during secondary treatment
# 100% was assumed to be transformed in TreatII and thus also TreatIII
TreatII_D.transfers = [cp.ConstTransfer(1, EndOfTreatII_T, priority=1)]
TreatII_T.transfers = [cp.ConstTransfer(1, EndOfTreatII_T, priority=1)]
TreatII_M.transfers = [cp.ConstTransfer(1, EndOfTreatII_M, priority=1)]

# From secondary treatment to sludge
# Two references were found on the removal of nano-ZnO to sludge.
Removal_Hou = nr.uniform(1, 1, 5000)
Removal_Chauque = nr.uniform(0.97, 0.99, 5000)
RemovalData_TreatII = np.concatenate([Removal_Hou, Removal_Chauque])

EndOfTreatII_T.transfers= [cp.RandomChoiceTransfer(RemovalData_TreatII, STPsludge_T, priority=2), 
                           cp.ConstTransfer(1, STPeffluent_T, priority=1)]

# We make the assumption that matrix-embedded ENMs behave as microplastics in WWTP, since they have about the same size.
# Four sources are available that studied the removal of MPs after secondary treatment in Europe:
# Murphy et al. 2016: 98.41% go to sludge, with a coefficient of variation of 16%.
# Talvitie et al. 2015: from their data, we build a triangular distribution with min of 96.5%, mode of 97.8% and max of 98.1%.
# Magnusson and Norén 2014: uniform distribution within 99.94% and 99.95%.
# Lares et al. 2018: from their data, we build a triangular distribution with min of 81.1%, mode of 98.3% and max of 98.3%.
Removal_Murphy = nr.triangular(0.9841*(1-0.16), 0.9841, 0.9841*(1+0.16), 2500)
Removal_Talvitie = nr.triangular(0.965, 0.978, 0.981, 2500)
Removal_Magnusson = nr.uniform(0.9994, 0.9995, 2500)
Removal_Lares = nr.triangular(0.811, 0.983, 0.983, 2500)
RemovalData_TreatII_M = np.concatenate([Removal_Murphy, Removal_Talvitie, Removal_Magnusson])

EndOfTreatII_M.transfers = [cp.RandomChoiceTransfer(RemovalData_TreatII_M, STPsludge_M, priority=2),
                      cp.ConstTransfer(1, STPeffluent_M, priority=1)]


# In[40]:


## Transfers from tertiary treatment

# Transformations
TreatIII_D.transfers =[cp.ConstTransfer(1, EndOfTreatIII_T, priority=1)]
TreatIII_T.transfers =[cp.ConstTransfer(1, EndOfTreatIII_T, priority=1)]
TreatIII_M.transfers =[cp.ConstTransfer(1, EndOfTreatIII_M, priority=1)]

# No reference was found on the removal of nano-ZnO to sludge after tertiary treatment. As a worst case scenario, the same data as for 
# secondary treatment were used.
EndOfTreatIII_T.transfers= [cp.RandomChoiceTransfer(RemovalData_TreatII, STPsludge_T, priority=2), 
                           cp.ConstTransfer(1, STPeffluent_T, priority=1)]

# We make the assumption that matrix-embedded ENMs behave as microplastics in WWTP, since they have about the same size.
# Two sources are available that studied the removal of MPs after tertiary treatment in Europe:
# Magni et al. 2019: from their data, we build a triangular distribution with min of 67.5%, mode of 84% and max of 91%.
# Lares et al. 2018: from their data, we build a triangular distribution with min of 94.6%, mode of 99.3% and max of 99.8%.
Removal_Magni = nr.triangular(0.675, 0.84, 0.91, 5000)
Removal_Lares = nr.triangular(0.946, 0.993, 0.998, 5000)
RemovalData_TreatIII_M = np.concatenate([Removal_Magni, Removal_Lares])

EndOfTreatIII_M.transfers = [cp.RandomChoiceTransfer(RemovalData_TreatIII_M, STPsludge_M, priority=2),
                             cp.ConstTransfer(1, STPeffluent_M, priority=1)]


# In[41]:


# Transfers from sludge

# To incineration
# For year 2014: 37.77% incinerated in Poland.
# Mean of this value for Europe for year 2014: 30.1% (this model).
# It results a scaling factor of 1.255. Before multiplication, distributions must not exceed 1/1.255 = 0.797
SF_SG_WIP = 1.255

SG_WIIP_y0_data = (nr.triangular(0.1887, 0.209, 0.2293, s))*SF_SG_WIP
SG_WIIP_y1_data = (nr.triangular(0.1822, 0.213, 0.2438, s))*SF_SG_WIP
SG_WIIP_y2_data = (nr.triangular(0.1754, 0.217, 0.2586, s))*SF_SG_WIP
SG_WIIP_y3_data = (nr.triangular(0.1792, 0.221, 0.2628, s))*SF_SG_WIP
SG_WIIP_y4_data = (nr.triangular(0.1943, 0.225, 0.2557, s))*SF_SG_WIP
SG_WIIP_y5_data = (nr.triangular(0.2098, 0.229, 0.2482, s))*SF_SG_WIP
SG_WIIP_y6_data = (nr.triangular(0.2170, 0.256, 0.2950, s))*SF_SG_WIP
SG_WIIP_y7_data = (nr.triangular(0.2228, 0.286, 0.3492, s))*SF_SG_WIP
SG_WIIP_y8_data = (nr.triangular(0.2411, 0.317, 0.3929, s))*SF_SG_WIP
SG_WIIP_y9_data = (nr.triangular(0.2526, 0.319, 0.3854, s))*SF_SG_WIP
SG_WIIP_y10_data = (nr.triangular(0.2643, 0.321, 0.3777, s))*SF_SG_WIP
SG_WIIP_y11_data = (nr.triangular(0.2231, 0.315, 0.4069, s))*SF_SG_WIP
SG_WIIP_y12_data = (nr.triangular(0.1868, 0.315, 0.4432, s))*SF_SG_WIP
SG_WIIP_y13_data = (nr.triangular(0.1780, 0.308, 0.4381, s))*SF_SG_WIP
SG_WIIP_y14_data = (nr.triangular(0.1693, 0.301, 0.4327, s))*SF_SG_WIP
SG_WIIP_y15_data = (nr.triangular(0.1614, 0.315, 0.4686, s))*SF_SG_WIP
SG_WIIP_y16_data = (nr.triangular(0.1645, 0.329, 0.4935, s))*SF_SG_WIP
SG_WIIP_y17_data = (nr.triangular(0.1715, 0.343, 0.5145, s))*SF_SG_WIP
SG_WIIP_y18_data = (nr.triangular(0.1785, 0.357, 0.5355, s))*SF_SG_WIP
SG_WIIP_y19_data = (nr.triangular(0.1901, 0.371, 0.5519, s))*SF_SG_WIP
SG_WIIP_y20_data = (nr.triangular(0.2171, 0.386, 0.5549, s))*SF_SG_WIP

SG_WIIP_y0 = cp.TransferDistribution(nr.choice, [SG_WIIP_y0_data])
SG_WIIP_y1 = cp.TransferDistribution(nr.choice, [SG_WIIP_y1_data])
SG_WIIP_y2 = cp.TransferDistribution(nr.choice, [SG_WIIP_y2_data])
SG_WIIP_y3 = cp.TransferDistribution(nr.choice, [SG_WIIP_y3_data])
SG_WIIP_y4 = cp.TransferDistribution(nr.choice, [SG_WIIP_y4_data])
SG_WIIP_y5 = cp.TransferDistribution(nr.choice, [SG_WIIP_y5_data])
SG_WIIP_y6 = cp.TransferDistribution(nr.choice, [SG_WIIP_y6_data])
SG_WIIP_y7 = cp.TransferDistribution(nr.choice, [SG_WIIP_y7_data])
SG_WIIP_y8 = cp.TransferDistribution(nr.choice, [SG_WIIP_y8_data])
SG_WIIP_y9 = cp.TransferDistribution(nr.choice, [SG_WIIP_y9_data])
SG_WIIP_y10 = cp.TransferDistribution(nr.choice, [SG_WIIP_y10_data])
SG_WIIP_y11 = cp.TransferDistribution(nr.choice, [SG_WIIP_y11_data])
SG_WIIP_y12 = cp.TransferDistribution(nr.choice, [SG_WIIP_y12_data])
SG_WIIP_y13 = cp.TransferDistribution(nr.choice, [SG_WIIP_y13_data])
SG_WIIP_y14 = cp.TransferDistribution(nr.choice, [SG_WIIP_y14_data])
SG_WIIP_y15 = cp.TransferDistribution(nr.choice, [SG_WIIP_y15_data])
SG_WIIP_y16 = cp.TransferDistribution(nr.choice, [SG_WIIP_y16_data])
SG_WIIP_y17 = cp.TransferDistribution(nr.choice, [SG_WIIP_y17_data])
SG_WIIP_y18 = cp.TransferDistribution(nr.choice, [SG_WIIP_y18_data])
SG_WIIP_y19 = cp.TransferDistribution(nr.choice, [SG_WIIP_y19_data])
SG_WIIP_y20 = cp.TransferDistribution(nr.choice, [SG_WIIP_y20_data])

# To landfill
# For year 2014: 14.13% landfilled in Poland.
# Mean of this value for Europe for year 2014: 10.5% (this model).
# It results a scaling factor of 1.346. Before multiplication, distributions must not exceed 1/1.346 = 0.743
SF_SG_LF = 1.346

SG_LF_y0_data = (nr.triangular(0.1887, 0.209, 0.2293, s))*SF_SG_LF
SG_LF_y1_data = (nr.triangular(0.1780, 0.208, 0.2380, s))*SF_SG_LF
SG_LF_y2_data = (nr.triangular(0.1681, 0.208, 0.2479, s))*SF_SG_LF
SG_LF_y3_data = (nr.triangular(0.1678, 0.207, 0.2462, s))*SF_SG_LF
SG_LF_y4_data = (nr.triangular(0.1779, 0.206, 0.2341, s))*SF_SG_LF
SG_LF_y5_data = (nr.triangular(0.1878, 0.205, 0.2222, s))*SF_SG_LF
SG_LF_y6_data = (nr.triangular(0.1729, 0.204, 0.2351, s))*SF_SG_LF
SG_LF_y7_data = (nr.triangular(0.1581, 0.203, 0.2479, s))*SF_SG_LF
SG_LF_y8_data = (nr.triangular(0.1544, 0.203, 0.2516, s))*SF_SG_LF
SG_LF_y9_data = (nr.triangular(0.1457, 0.184, 0.2223, s))*SF_SG_LF
SG_LF_y10_data = (nr.triangular(0.1375, 0.167, 0.1965, s))*SF_SG_LF
SG_LF_y11_data = (nr.triangular(0.1069, 0.151, 0.1951, s))*SF_SG_LF
SG_LF_y12_data = (nr.triangular(0.0818, 0.138, 0.1942, s))*SF_SG_LF
SG_LF_y13_data = (nr.triangular(0.0699, 0.121, 0.1721, s))*SF_SG_LF
SG_LF_y14_data = (nr.triangular(0.0591, 0.105, 0.1509, s))*SF_SG_LF
SG_LF_y15_data = (nr.triangular(0.0567, 0.102, 0.1473, s))*SF_SG_LF
SG_LF_y16_data = (nr.triangular(0.0539, 0.098, 0.1421, s))*SF_SG_LF
SG_LF_y17_data = (nr.triangular(0.0516, 0.095, 0.1384, s))*SF_SG_LF
SG_LF_y18_data = (nr.triangular(0.0579, 0.091, 0.1241, s))*SF_SG_LF
SG_LF_y19_data = (nr.triangular(0.0642, 0.088, 0.1118, s))*SF_SG_LF
SG_LF_y20_data = (nr.triangular(0.0692, 0.084, 0.0988, s))*SF_SG_LF

SG_LF_y0 = cp.TransferDistribution(nr.choice, [SG_LF_y0_data])
SG_LF_y1 = cp.TransferDistribution(nr.choice, [SG_LF_y1_data])
SG_LF_y2 = cp.TransferDistribution(nr.choice, [SG_LF_y2_data])
SG_LF_y3 = cp.TransferDistribution(nr.choice, [SG_LF_y3_data])
SG_LF_y4 = cp.TransferDistribution(nr.choice, [SG_LF_y4_data])
SG_LF_y5 = cp.TransferDistribution(nr.choice, [SG_LF_y5_data])
SG_LF_y6 = cp.TransferDistribution(nr.choice, [SG_LF_y6_data])
SG_LF_y7 = cp.TransferDistribution(nr.choice, [SG_LF_y7_data])
SG_LF_y8 = cp.TransferDistribution(nr.choice, [SG_LF_y8_data])
SG_LF_y9 = cp.TransferDistribution(nr.choice, [SG_LF_y9_data])
SG_LF_y10 = cp.TransferDistribution(nr.choice, [SG_LF_y10_data])
SG_LF_y11 = cp.TransferDistribution(nr.choice, [SG_LF_y11_data])
SG_LF_y12 = cp.TransferDistribution(nr.choice, [SG_LF_y12_data])
SG_LF_y13 = cp.TransferDistribution(nr.choice, [SG_LF_y13_data])
SG_LF_y14 = cp.TransferDistribution(nr.choice, [SG_LF_y14_data])
SG_LF_y15 = cp.TransferDistribution(nr.choice, [SG_LF_y15_data])
SG_LF_y16 = cp.TransferDistribution(nr.choice, [SG_LF_y16_data])
SG_LF_y17 = cp.TransferDistribution(nr.choice, [SG_LF_y17_data])
SG_LF_y18 = cp.TransferDistribution(nr.choice, [SG_LF_y18_data])
SG_LF_y19 = cp.TransferDistribution(nr.choice, [SG_LF_y19_data])
SG_LF_y20 = cp.TransferDistribution(nr.choice, [SG_LF_y20_data])

STPsludge_M.transfers =[cp.TimeDependendDistributionTransfer([SG_WIIP_y0,
                                                            SG_WIIP_y1,SG_WIIP_y2,SG_WIIP_y3,SG_WIIP_y4,SG_WIIP_y5,
                                                            SG_WIIP_y6,SG_WIIP_y7,SG_WIIP_y8,SG_WIIP_y9,SG_WIIP_y10,
                                                            SG_WIIP_y11,SG_WIIP_y12,SG_WIIP_y13,SG_WIIP_y14,SG_WIIP_y15,
                                                            SG_WIIP_y16,SG_WIIP_y17,SG_WIIP_y18,SG_WIIP_y19,SG_WIIP_y20], 
                                                            WIP_M, STPsludge_M, priority=2),
                      cp.TimeDependendDistributionTransfer([SG_LF_y0,
                                                            SG_LF_y1,SG_LF_y2,SG_LF_y3,SG_LF_y4,SG_LF_y5,
                                                            SG_LF_y6,SG_LF_y7,SG_LF_y8,SG_LF_y9,SG_LF_y10,
                                                            SG_LF_y11,SG_LF_y12,SG_LF_y13,SG_LF_y14,SG_LF_y15,
                                                            SG_LF_y16,SG_LF_y17,SG_LF_y18,SG_LF_y19,SG_LF_y20],
                                                            Slud_Landfill_M, STPsludge_M, priority=2),
                      cp.ConstTransfer(1, STsoil_M, priority=1)]
STPsludge_T.transfers =[cp.TimeDependendDistributionTransfer([SG_WIIP_y0,
                                                            SG_WIIP_y1,SG_WIIP_y2,SG_WIIP_y3,SG_WIIP_y4,SG_WIIP_y5,
                                                            SG_WIIP_y6,SG_WIIP_y7,SG_WIIP_y8,SG_WIIP_y9,SG_WIIP_y10,
                                                            SG_WIIP_y11,SG_WIIP_y12,SG_WIIP_y13,SG_WIIP_y14,SG_WIIP_y15,
                                                            SG_WIIP_y16,SG_WIIP_y17,SG_WIIP_y18,SG_WIIP_y19,SG_WIIP_y20], 
                                                            WIP_T, STPsludge_T, priority=2),
                      cp.TimeDependendDistributionTransfer([SG_LF_y0,
                                                            SG_LF_y1,SG_LF_y2,SG_LF_y3,SG_LF_y4,SG_LF_y5,
                                                            SG_LF_y6,SG_LF_y7,SG_LF_y8,SG_LF_y9,SG_LF_y10,
                                                            SG_LF_y11,SG_LF_y12,SG_LF_y13,SG_LF_y14,SG_LF_y15,
                                                            SG_LF_y16,SG_LF_y17,SG_LF_y18,SG_LF_y19,SG_LF_y20],
                                                            Slud_Landfill_T, STPsludge_T, priority=2),
                      cp.ConstTransfer(1, STsoil_T, priority=1)]

STPeffluent_M.transfers = [cp.ConstTransfer(1, STPeffluent_SurfWater_M, priority=1)]
STPeffluent_T.transfers = [cp.ConstTransfer(1, STPeffluent_SurfWater_T, priority=1)]


# In[42]:


### SOLID WASTE MANAGEMENT


# In[43]:


# Transfers from Mixed Municipal Solid Waste

# for MSW there is first an array built with 's' sampled values from each distribution of the different sources
# In a second step from this sampled data, one value is selected and multiplied by the scaling factor for Poland.
# Eurostat, for year 2014: 77.7% landfilled in Poland.
# Mean of this value for Europe for year 2014: 47.87% (this model).
# It results a scaling factor of 1.623.
# The overall distributions must not exceed 1, so 0.616 (=1/1.623) before multiplication by 1.623.
SF_MW_LF = 1.623

MSW_LF_Data_y0 = SF_MW_LF*(np.concatenate([tf.TriangTruncDet(0.461, 0.922, 1.383, s, 0, 0.616), tf.TriangTruncDet(0.411, 0.822, 1.233, s, 0, 0.616), tf.TriangTruncDet(0.3978, 0.765, 1.1628, s, 0, 0.616)] ))
MSW_LF_Data_y1 = SF_MW_LF*(np.concatenate([tf.TriangTruncDet(0.4495, 0.899, 1.3485, s, 0, 0.616), tf.TriangTruncDet(0.4035, 0.807, 1.2105, s, 0, 0.616), tf.TriangTruncDet(0.38948, 0.749, 1.1385, s, 0, 0.616)] ))
MSW_LF_Data_y2 = SF_MW_LF*(np.concatenate([tf.TriangTruncDet(0.4708, 0.877, 1.3478, s, 0, 0.616), tf.TriangTruncDet(0.3955, 0.791, 1.1865, s, 0, 0.616), tf.TriangTruncDet(0.3817, 0.734, 1.11568, s, 0, 0.616)] ))
MSW_LF_Data_y3 = SF_MW_LF*(np.concatenate([tf.TriangTruncDet(0.5231, 0.855, 1.2056, s, 0, 0.616), tf.TriangTruncDet(0.4035, 0.773, 1.1765, s, 0, 0.616), tf.TriangTruncDet(0.3760, 0.723, 1.099, s, 0, 0.616)] ))
MSW_LF_Data_y4 = SF_MW_LF*(np.concatenate([tf.TriangTruncDet(0.5713, 0.832, 1.1149, s, 0, 0.616), tf.TriangTruncDet(0.4347, 0.76, 1.1947, s, 0, 0.616), tf.TriangTruncDet(0.3645, 0.701, 1.0655, s, 0, 0.616)] ))
MSW_LF_Data_y5 = SF_MW_LF*(np.concatenate([nr.uniform(0.616, 0.616, s), tf.TriangTruncDet(0.3826, 0.733, 1.0629, s, 0, 0.616), tf.TriangTruncDet(0.3484, 0.67, 0.9916, s, 0, 0.616)] ))
MSW_LF_Data_y6 = SF_MW_LF*(np.concatenate([nr.uniform(0.616, 0.616, s), tf.TriangTruncDet(0.4021, 0.703, 1.1051, s, 0, 0.616), tf.TriangTruncDet(0.3406, 0.655, 0.9694, s, 0, 0.616)] ))
MSW_LF_Data_y7 = SF_MW_LF*(np.concatenate([nr.uniform(0.616, 0.616, s), tf.TriangTruncDet(0.3581, 0.686, 0.9947, s, 0, 0.616), tf.TriangTruncDet(0.33488, 0.644, 0.95312, s, 0, 0.616)] ))
MSW_LF_Data_y8 = SF_MW_LF*(np.concatenate([tf.TriangTruncDet(0.5995, 0.728, 0.8565, s, 0, 0.616), tf.TriangTruncDet(0.3815, 0.667, 0.9525, s, 0, 0.616), tf.TriangTruncDet(0.31772, 0.611, 0.90428, s, 0, 0.616)] ))
MSW_LF_Data_y9 = SF_MW_LF*(np.concatenate([tf.TriangTruncDet(0.5175, 0.658, 0.7985, s, 0, 0.616), tf.TriangTruncDet(0.3377, 0.647, 0.9563, s, 0, 0.616), tf.TriangTruncDet(0.312, 0.6, 0.888, s, 0, 0.616)] ))
MSW_LF_Data_y10 = SF_MW_LF*(np.concatenate([tf.TriangTruncDet(0.5072, 0.597, 0.6868, s, 0, 0.616), tf.TriangTruncDet(0.3586, 0.627, 0.8954, s, 0, 0.616), tf.TriangTruncDet(0.3042, 0.585, 0.8658, s, 0, 0.616)] ))
MSW_LF_Data_y11 = SF_MW_LF*(np.concatenate([tf.TriangTruncDet(0.4582, 0.57, 0.6818, s, 0, 0.616), tf.TriangTruncDet(0.3054, 0.585, 0.8646, s, 0, 0.616), tf.TriangTruncDet(0.28652, 0.551, 0.81548, s, 0, 0.616)] ))
MSW_LF_Data_y12 = SF_MW_LF*(np.concatenate([tf.TriangTruncDet(0.4193, 0.553, 0.6867, s, 0, 0.616), tf.TriangTruncDet(0.3077, 0.538, 0.7683, s, 0, 0.616), tf.TriangTruncDet(0.27456, 0.528, 0.78144, s, 0, 0.616)] ))
MSW_LF_Data_y13 = SF_MW_LF*(np.concatenate([tf.TriangTruncDet(0.4355, 0.536, 0.6365, s, 0, 0.616), tf.TriangTruncDet(0.2662, 0.51, 0.7538, s, 0, 0.616), tf.TriangTruncDet(0.25792, 0.496, 0.73408, s, 0, 0.616)] ))
MSW_LF_Data_y14 = SF_MW_LF*(np.concatenate([nr.triangular(0.4200, 0.487, 0.5540, s), tf.TriangTruncDet(0.2740, 0.479, 0.6840, s, 0, 0.616), tf.TriangTruncDet(0.24596, 0.473, 0.70004, s, 0, 0.616)] ))
MSW_LF_Data_y15 = SF_MW_LF*(np.concatenate([nr.triangular(0.3831, 0.474, 0.5649, s), tf.TriangTruncDet(0.2219, 0.425, 0.6282, s, 0, 0.616), tf.TriangTruncDet(0.23296, 0.448, 0.66304, s, 0, 0.616)] ))
MSW_LF_Data_y16 = SF_MW_LF*(np.concatenate([nr.triangular(0.3468, 0.46, 0.5732, s), nr.triangular(0.1875, 0.375, 0.5625, s), tf.TriangTruncDet(0.206, 0.412, 0.618, s, 0, 0.616)] ))
MSW_LF_Data_y17 = SF_MW_LF*(np.concatenate([nr.triangular(0.3113, 0.445, 0.5787, s), nr.triangular(0.1595, 0.319, 0.4785, s), nr.triangular(0.1895, 0.379, 0.5685, s)] ))
MSW_LF_Data_y18 = SF_MW_LF*(np.concatenate([nr.triangular(0.3197, 0.429, 0.5383, s), nr.triangular(0.128, 0.256, 0.384, s), nr.triangular(0.1725, 0.345, 0.5175, s)] ))
MSW_LF_Data_y19 = SF_MW_LF*(np.concatenate([nr.triangular(0.3250, 0.411, 0.4970, s), nr.triangular(0.0925, 0.185, 0.2775, s), nr.triangular(0.154, 0.308, 0.462, s)] ))
MSW_LF_Data_y20 = SF_MW_LF*(np.concatenate([nr.triangular(0.3271, 0.391, 0.4549, s), nr.triangular(0.0515, 0.103, 0.1545, s), nr.triangular(0.1345, 0.269, 0.4035, s)] ))

MSW_LF_y0 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y0])
MSW_LF_y1 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y1])
MSW_LF_y2 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y2])
MSW_LF_y3 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y3])
MSW_LF_y4 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y4])
MSW_LF_y5 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y5])
MSW_LF_y6 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y6])
MSW_LF_y7 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y7])
MSW_LF_y8 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y8])
MSW_LF_y9 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y9])
MSW_LF_y10 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y10])
MSW_LF_y11 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y11])
MSW_LF_y12 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y12])
MSW_LF_y13 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y13])
MSW_LF_y14 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y14])
MSW_LF_y15 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y15])
MSW_LF_y16 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y16])
MSW_LF_y17 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y17])
MSW_LF_y18 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y18])
MSW_LF_y19 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y19])
MSW_LF_y20 = cp.TransferDistribution(nr.choice, [MSW_LF_Data_y20])

MMSW.transfers = [cp.TimeDependendDistributionTransfer([MSW_LF_y0,
                                                        MSW_LF_y1,MSW_LF_y2,MSW_LF_y3,MSW_LF_y4,MSW_LF_y5,
                                                        MSW_LF_y6,MSW_LF_y7,MSW_LF_y8,MSW_LF_y9,MSW_LF_y10,
                                                        MSW_LF_y11,MSW_LF_y12,MSW_LF_y13,MSW_LF_y14,MSW_LF_y15,
                                                        MSW_LF_y16,MSW_LF_y17,MSW_LF_y18,MSW_LF_y19,MSW_LF_y20],
                                                        MMSW_Landfill_P, MMSW, priority=2), # From MMSW to Landfill
                  cp.ConstTransfer(1, WIP_P, priority=1)]


# In[44]:


# Transfers from Packaging Waste

# Eurostat, for year 2014: 38.29% goes to MMSW in Poland.
# Mean of this value for Europe in year 2014: 21.3% (this model).
# It results a scaling factor of 1.796.
# The overall distributions must not exceed 1, so 0.557 (=1/1.796) before multiplication by 1.796
SF_PW_MW = 1.796

PW_MW_y0_data = SF_PW_MW*(tf.TriangTruncDet(0.2925, 0.52, 0.7475, s, 0, 0.557))
PW_MW_y1_data = SF_PW_MW*(tf.TriangTruncDet(0.2998, 0.5, 0.7003, s, 0, 0.557))
PW_MW_y2_data = SF_PW_MW*(tf.TriangTruncDet(0.3030, 0.476, 0.6490, s, 0, 0.557))
PW_MW_y3_data = SF_PW_MW*(nr.triangular(0.3488, 0.451, 0.5532, s))
PW_MW_y4_data = SF_PW_MW*(nr.triangular(0.3516, 0.427, 0.5024, s))
PW_MW_y5_data = SF_PW_MW*(nr.triangular(0.3513, 0.42, 0.4887, s))
PW_MW_y6_data = SF_PW_MW*(nr.triangular(0.3457, 0.407, 0.4683, s))
PW_MW_y7_data = SF_PW_MW*(nr.triangular(0.2887, 0.365, 0.4413, s))
PW_MW_y8_data = SF_PW_MW*(nr.triangular(0.2358, 0.322, 0.4082, s))
PW_MW_y9_data = SF_PW_MW*(nr.triangular(0.2166, 0.28, 0.3434, s))
PW_MW_y10_data = SF_PW_MW*(nr.triangular(0.1952, 0.237, 0.2788, s))
PW_MW_y11_data = SF_PW_MW*(nr.triangular(0.1869, 0.227, 0.2671, s))
PW_MW_y12_data = SF_PW_MW*(nr.triangular(0.1771, 0.215, 0.2529, s))
PW_MW_y13_data = SF_PW_MW*(nr.triangular(0.1163, 0.208, 0.2997, s))
PW_MW_y14_data = SF_PW_MW*(nr.triangular(0.1191, 0.213, 0.3069, s))
PW_MW_y15_data = SF_PW_MW*(nr.triangular(0.1191, 0.213, 0.3069, s))
PW_MW_y16_data = SF_PW_MW*(nr.triangular(0.0718, 0.141, 0.2102, s))
PW_MW_y17_data = SF_PW_MW*(nr.triangular(0.0585, 0.117, 0.1755, s))
PW_MW_y18_data = SF_PW_MW*(nr.triangular(0.0465, 0.093, 0.1395, s))
PW_MW_y19_data = SF_PW_MW*(nr.triangular(0.0345, 0.069, 0.1035, s))
PW_MW_y20_data = SF_PW_MW*(nr.triangular(0.023, 0.046, 0.069, s))

PW_MW_y0 = cp.TransferDistribution(nr.choice, [PW_MW_y0_data])
PW_MW_y1 = cp.TransferDistribution(nr.choice, [PW_MW_y1_data])
PW_MW_y2 = cp.TransferDistribution(nr.choice, [PW_MW_y2_data])
PW_MW_y3 = cp.TransferDistribution(nr.choice, [PW_MW_y3_data])
PW_MW_y4 = cp.TransferDistribution(nr.choice, [PW_MW_y4_data])
PW_MW_y5 = cp.TransferDistribution(nr.choice, [PW_MW_y5_data])
PW_MW_y6 = cp.TransferDistribution(nr.choice, [PW_MW_y6_data])
PW_MW_y7 = cp.TransferDistribution(nr.choice, [PW_MW_y7_data])
PW_MW_y8 = cp.TransferDistribution(nr.choice, [PW_MW_y8_data])
PW_MW_y9 = cp.TransferDistribution(nr.choice, [PW_MW_y9_data])
PW_MW_y10 = cp.TransferDistribution(nr.choice, [PW_MW_y10_data])
PW_MW_y11 = cp.TransferDistribution(nr.choice, [PW_MW_y11_data])
PW_MW_y12 = cp.TransferDistribution(nr.choice, [PW_MW_y12_data])
PW_MW_y13 = cp.TransferDistribution(nr.choice, [PW_MW_y13_data])
PW_MW_y14 = cp.TransferDistribution(nr.choice, [PW_MW_y14_data])
PW_MW_y15 = cp.TransferDistribution(nr.choice, [PW_MW_y15_data])
PW_MW_y16 = cp.TransferDistribution(nr.choice, [PW_MW_y16_data])
PW_MW_y17 = cp.TransferDistribution(nr.choice, [PW_MW_y17_data])
PW_MW_y18 = cp.TransferDistribution(nr.choice, [PW_MW_y18_data])
PW_MW_y19 = cp.TransferDistribution(nr.choice, [PW_MW_y19_data])
PW_MW_y20 = cp.TransferDistribution(nr.choice, [PW_MW_y20_data])

PackW.transfers = [cp.TimeDependendDistributionTransfer([PW_MW_y0,
                                                         PW_MW_y1,PW_MW_y2,PW_MW_y3,PW_MW_y4,PW_MW_y5,
                                                         PW_MW_y6,PW_MW_y7,PW_MW_y8,PW_MW_y9,PW_MW_y10,
                                                         PW_MW_y11,PW_MW_y12,PW_MW_y13,PW_MW_y14,PW_MW_y15,
                                                         PW_MW_y16,PW_MW_y17,PW_MW_y18,PW_MW_y19,PW_MW_y20],
                                                         MMSW, PackW, priority=2),
                   cp.ConstTransfer(1, Sorting_PackW, priority=1)]


# In[45]:


# Transfers of CDW, same as for Europe
CDW_LF_y0 = cp.TransferDistribution(nr.triangular, [0.4028, 0.646, 0.8892])
CDW_LF_y1 = cp.TransferDistribution(nr.triangular, [0.4155, 0.617, 0.8185])
CDW_LF_y2 = cp.TransferDistribution(nr.triangular, [0.4254, 0.588, 0.7506])
CDW_LF_y3 = cp.TransferDistribution(nr.triangular, [0.4324, 0.559, 0.6856])
CDW_LF_y4 = cp.TransferDistribution(nr.triangular, [0.4447, 0.54, 0.6353])
CDW_LF_y5 = cp.TransferDistribution(nr.triangular, [0.3709, 0.507, 0.6431])
CDW_LF_y6 = cp.TransferDistribution(nr.triangular, [0.3032, 0.474, 0.6448])
CDW_LF_y7 = cp.TransferDistribution(nr.triangular, [0.2416, 0.441, 0.6404])
CDW_LF_y8 = cp.TransferDistribution(nr.triangular, [0.2268, 0.408, 0.5892])
CDW_LF_y9 = cp.TransferDistribution(nr.triangular, [0.2115, 0.375, 0.5385])
CDW_LF_y10 = cp.TransferDistribution(nr.triangular, [0.1956, 0.342, 0.4884])
CDW_LF_y11 = cp.TransferDistribution(nr.triangular, [0.1650, 0.316, 0.4670])
CDW_LF_y12 = cp.TransferDistribution(nr.triangular, [0.1665, 0.291, 0.4155])
CDW_LF_y13 = cp.TransferDistribution(nr.triangular, [0.1436, 0.275, 0.4065])
CDW_LF_y14 = cp.TransferDistribution(nr.triangular, [0.1481, 0.259, 0.3699])
CDW_LF_y15 = cp.TransferDistribution(nr.triangular, [0.1096, 0.21, 0.3104])
CDW_LF_y16 = cp.TransferDistribution(nr.triangular, [0.0905, 0.181, 0.2715])
CDW_LF_y17 = cp.TransferDistribution(nr.triangular, [0.076, 0.152, 0.228])
CDW_LF_y18 = cp.TransferDistribution(nr.triangular, [0.0615, 0.123, 0.1845])
CDW_LF_y19 = cp.TransferDistribution(nr.triangular, [0.0465, 0.093, 0.1395])
CDW_LF_y20 = cp.TransferDistribution(nr.triangular, [0.032, 0.0640, 0.0960])

CDW.transfers = [cp.TimeDependendDistributionTransfer([CDW_LF_y0,
                                                       CDW_LF_y1,CDW_LF_y2,CDW_LF_y3,CDW_LF_y4,CDW_LF_y5,
                                                       CDW_LF_y6,CDW_LF_y7,CDW_LF_y8,CDW_LF_y9,CDW_LF_y10,
                                                       CDW_LF_y11,CDW_LF_y12,CDW_LF_y13,CDW_LF_y14,CDW_LF_y15,
                                                       CDW_LF_y16,CDW_LF_y17,CDW_LF_y18,CDW_LF_y19,CDW_LF_y20],
                                                       CDW_Landfill_P, CDW, priority=2), # Landfill is the target
                 cp.ConstTransfer(1, Sorting_CDW, priority=1)]


# In[46]:


### TRANSFERS FROM SORTING
# all these processes were kept static, so there are no time-dependent transfers
# thus the coefficient of variance is kept to 50%  


# In[47]:


# Sorting of Packaging Waste
Sorting_PackW.transfers = [cp.ConstTransfer(1, WW_N, priority=1)]


# In[48]:


# Sorting of CDW   
Sorting_CDW.transfers = [cp.ConstTransfer(1, Sorting_CDW_Mineral, priority=1)] 
  
Reprocessing_Mineral = np.concatenate([nr.uniform(0, 0.28, int(s*0.8)), nr.triangular(0.28, 0.28, 0.294, int(s*0.2))])
Sorting_CDW_Mineral.transfers= [cp.RandomChoiceTransfer(Reprocessing_Mineral, Reprocess_Mineral_P, priority=2),
                                cp.ConstTransfer(1, SortCDW_Landfill_P, priority=1)]


# In[49]:


### TRANSFERS FROM REPROCESSING


# In[50]:


## Reprocessing of CDW from minerals

# from crushing minerals to air
Reprocess_Mineral_P.transfers =[cp.StochasticTransfer(tf.TrapezTrunc, [0.05, 0.16, 0.49, 0.49, 1, 0, 1], Air_Mineral, priority=2), # since Tc from moulding to reuse is 1, here we skip moulding to reuse to simplify the code
                                cp.ConstTransfer(1, Sorting_CDW_Mineral, priority=1)]

Sorting_CDW_Mineral.transfers =[cp.StochasticTransfer(tf.TriangTrunc, [0.6413, 1.03, 1, 0, 1], SortCDWMiner_Landfill_P, priority=2),
                            cp.StochasticTransfer(tf.TriangTrunc, [0.05, 1.01, 1, 0, 1], Air_Mineral, priority=2),
                            cp.ConstTransfer(1, SortCDWMiner_Reuse_P, priority=1)]
                           
# release form
Air_Mineral.transfers=[cp.StochasticTransfer(tf.TriangTrunc, [0.2, 1.47, 1, 0, 1], Air_NM, priority=2),
                       cp.ConstTransfer(1, RPAir_M, priority=1)]

# Allocate all release to air with mixed N and M
# allocation of Air_NM for the fraction of 0.2
Air_NM.transfers=[cp.StochasticTransfer(tf.TriangTrunc, [0.1535, 1.07, 1, 0, 1], RPAir_N, priority=2),
                  cp.ConstTransfer(1, RPAir_M,priority=1)]


# In[51]:


### TRANSFERS FROM WIP


# In[52]:


WIP_P.transfers = [cp.StochasticTransfer(nr.uniform, [0, 1], Burning_N, priority=1),
                  cp.StochasticTransfer(nr.uniform, [0, 1], Burning_T, priority=1)]

WIP_M.transfers = [cp.StochasticTransfer(nr.uniform, [0, 1], Burning_N, priority=1),
                  cp.StochasticTransfer(nr.uniform, [0, 1], Burning_T, priority=1)]

WIP_T.transfers = [cp.ConstTransfer(1, Burning_T, priority=1)]


# In[53]:


# Transfers to bottom / fly ash 
ToFlyAsh_Data = np.concatenate([
    nr.triangular(0.10, 0.19, 0.29, int(s*0.5)), # Walser et al. 2012
    np.concatenate([nr.triangular(0.021, 0.03, 0.03, int(s*0.5*0.058)), nr.uniform(0.03, 0.09, int(s*0.5*0.769)), nr.triangular(0.09, 0.09, 0.117, int(s*0.5*0.173))]) # Oischinger et al. 2019
                   ])

Burning_N.transfers =[cp.RandomChoiceTransfer(ToFlyAsh_Data, Flyash_N, priority=2),
                      cp.ConstTransfer(1, Bottomash_N, priority=1)]
Burning_T.transfers =[cp.RandomChoiceTransfer(ToFlyAsh_Data, Flyash_T, priority=2),
                      cp.ConstTransfer(1, Bottomash_T, priority=1)]


# In[54]:


# Transfers from fly ash
Flyash_N.transfers =[cp.StochasticTransfer(nr.triangular, [0.000025, 0.00005, 0.000075], WIP_Air_N, priority=2), # 1- 0.99995 (filter efficiency)
                     cp.StochasticTransfer(nr.triangular, [0, 0.0001, 0.00015], Acidwashing_N, priority=2),
                     cp.ConstTransfer(1, Filterash_N, priority=1)]
Flyash_T.transfers =[cp.StochasticTransfer(nr.triangular, [0.000025, 0.00005, 0.000075], WIP_Air_T, priority=2), # 1- 0.99995 (filter efficiency)
                     cp.StochasticTransfer(nr.triangular, [0, 0.0001, 0.00015], Acidwashing_T, priority=2),
                     cp.ConstTransfer(1, Filterash_T, priority=1)]


# In[55]:


# Transfers from filter ash
FA_LF_y0 = cp.TransferConstant(1)
FA_LF_y1 = cp.TransferConstant(1)
FA_LF_y2 = cp.TransferConstant(1)
FA_LF_y3 = cp.TransferConstant(1)
FA_LF_y4 = cp.TransferConstant(1)
FA_LF_y5 = cp.TransferConstant(1)
FA_LF_y6 = cp.TransferConstant(1)
FA_LF_y7 = cp.TransferConstant(1)
FA_LF_y8 = cp.TransferConstant(1)
FA_LF_y9 = cp.TransferConstant(1)
FA_LF_y10 = cp.TransferConstant(1)
FA_LF_y11 = cp.TransferConstant(1)
FA_LF_y12 = cp.TransferConstant(1)
FA_LF_y13 = cp.TransferConstant(1)
FA_LF_y14 = cp.TransferConstant(1)
FA_LF_y15 = cp.TransferConstant(1)
FA_LF_y16 = cp.TransferConstant(1)
FA_LF_y17 = cp.TransferConstant(1)
FA_LF_y18 = cp.TransferConstant(1)
FA_LF_y19 = cp.TransferConstant(1)
FA_LF_y20 = cp.TransferConstant(1)

Filterash_N.transfers = [cp.TimeDependendDistributionTransfer([FA_LF_y0,
                                                               FA_LF_y1,FA_LF_y2,FA_LF_y3,FA_LF_y4,FA_LF_y5,
                                                               FA_LF_y6,FA_LF_y7,FA_LF_y8,FA_LF_y9,FA_LF_y10,
                                                               FA_LF_y11,FA_LF_y12,FA_LF_y13,FA_LF_y14,FA_LF_y15,
                                                               FA_LF_y16,FA_LF_y17,FA_LF_y18,FA_LF_y19,FA_LF_y20],
                                                              Filterash_Landfill_N, Filterash_N, priority=2),
                         cp.ConstTransfer(1, Filterash_Reuse_N, priority=1)]
Filterash_T.transfers = [cp.TimeDependendDistributionTransfer([FA_LF_y0,
                                                               FA_LF_y1,FA_LF_y2,FA_LF_y3,FA_LF_y4,FA_LF_y5,
                                                               FA_LF_y6,FA_LF_y7,FA_LF_y8,FA_LF_y9,FA_LF_y10,
                                                               FA_LF_y11,FA_LF_y12,FA_LF_y13,FA_LF_y14,FA_LF_y15,
                                                               FA_LF_y16,FA_LF_y17,FA_LF_y18,FA_LF_y19,FA_LF_y20],
                                                              Filterash_Landfill_T, Filterash_T, priority=2),
                         cp.ConstTransfer(1, Filterash_Reuse_T, priority=1)]


# In[56]:


# Transfers from acid washing
Acidwashing_N.transfers =[cp.ConstTransfer(1, WW_T, priority=1)]
Acidwashing_T.transfers =[cp.ConstTransfer(1, WW_T, priority=1)]


# In[57]:


# Reprocessing of bottom ash
BA_R_y0 = cp.TransferDistribution(nr.triangular, [0.2445, 0.489, 0.7335])
BA_R_y1 = cp.TransferDistribution(nr.triangular, [0.243, 0.486, 0.729])
BA_R_y2 = cp.TransferDistribution(nr.triangular, [0.247025, 0.482, 0.716975])
BA_R_y3 = cp.TransferDistribution(nr.triangular, [0.253125, 0.45, 0.646875])
BA_R_y4 = cp.TransferDistribution(nr.triangular, [0.253125, 0.45, 0.646875])
BA_R_y5 = cp.TransferDistribution(nr.triangular, [0.236478333333333, 0.46, 0.683521666666667])
BA_R_y6 = cp.TransferDistribution(nr.triangular, [0.235, 0.47, 0.705])
BA_R_y7 = cp.TransferDistribution(nr.triangular, [0.24, 0.48, 0.72])
BA_R_y8 = cp.TransferDistribution(nr.triangular, [0.245, 0.49, 0.735])
BA_R_y9 = cp.TransferDistribution(nr.triangular, [0.260208333333333, 0.5, 0.739791666666667])
BA_R_y10 = cp.TransferDistribution(nr.triangular, [0.29172, 0.51, 0.72828])
BA_R_y11 = cp.TransferDistribution(nr.triangular, [0.24012, 0.46, 0.67988])
BA_R_y12 = cp.TransferDistribution(nr.triangular, [0.23452, 0.41, 0.58548])
BA_R_y13 = cp.TransferDistribution(nr.triangular, [0.215586, 0.413, 0.610414])
BA_R_y14 = cp.TransferDistribution(nr.triangular, [0.237952, 0.416, 0.594048])
BA_R_y15 = cp.TransferDistribution(nr.triangular, [0.227592, 0.436, 0.644408])
BA_R_y16 = cp.TransferDistribution(nr.triangular, [0.2165, 0.433, 0.6495])
BA_R_y17 = cp.TransferDistribution(nr.triangular, [0.2145, 0.429, 0.6435])
BA_R_y18 = cp.TransferDistribution(nr.triangular, [0.2125, 0.425, 0.6375])
BA_R_y19 = cp.TransferDistribution(nr.triangular, [0.211, 0.422, 0.633])
BA_R_y20 = cp.TransferDistribution(nr.triangular, [0.209, 0.418, 0.627])

Bottomash_N.transfers =[cp.TimeDependendDistributionTransfer([BA_R_y0,
                                                              BA_R_y1,BA_R_y2,BA_R_y3,BA_R_y4,BA_R_y5,
                                                              BA_R_y6,BA_R_y7,BA_R_y8,BA_R_y9,BA_R_y10,
                                                              BA_R_y11,BA_R_y12,BA_R_y13,BA_R_y14,BA_R_y15,
                                                              BA_R_y16,BA_R_y17,BA_R_y18,BA_R_y19,BA_R_y20],
                                                             Bottomash_Reuse_N, Bottomash_N, priority=2),
                        cp.ConstTransfer(1, Bottomash_Landfill_N, priority=1)]
Bottomash_T.transfers =[cp.TimeDependendDistributionTransfer([BA_R_y0,
                                                              BA_R_y1,BA_R_y2,BA_R_y3,BA_R_y4,BA_R_y5,
                                                              BA_R_y6,BA_R_y7,BA_R_y8,BA_R_y9,BA_R_y10,
                                                              BA_R_y11,BA_R_y12,BA_R_y13,BA_R_y14,BA_R_y15,
                                                              BA_R_y16,BA_R_y17,BA_R_y18,BA_R_y19,BA_R_y20],
                                                             Bottomash_Reuse_T, Bottomash_T, priority=2),
                        cp.ConstTransfer(1, Bottomash_Landfill_T, priority=1)]

