# -*- coding: utf-8 -*-
"""
Created on Tue Apr  2 11:23:23 2019

@author: wqi
"""

'''trapezoidal distribution when only min and max points are available'''
import numpy as np
import numpy.random as nr


    

def TraDis(x,CV_x, y, CV_y, s1=None): #x is available min, y is the available max, CV_x is the variation of x
    s=100000
    Tright=y*(1+CV_y)
    if Tright>1:
        Tright=1
    Tleft=x*(1-CV_x)
    if Tleft<0:
        Tleft=0 
    FLT=0.5*(x-Tleft)/(0.5*(x-Tleft)+(y-x)+0.5*(Tright-y)) #fraction of the left triangular distribution
    FRT=0.5*(Tright-y)/(0.5*(x-Tleft)+(y-x)+0.5*(Tright-y)) #fraction of the right triangular distribution
    FMU=(y-x)/(0.5*(x-Tleft)+(y-x)+0.5*(Tright-y)) #fraction of the middle uniform distribution
    
    LeftTriangular=nr.triangular(Tleft,x,x,int(FLT*s)) #equation based on Sana's excel file named 'Uncertainty_incl. values over 1", path 'G:\06_Austausch-Ordner\Exchange Veronique - Master\Exchange Veronique - Sana\Nanoparticles'
    MiddleUniform=nr.uniform(x,y,int(FMU*s))
    RightTriangular=nr.triangular(y,y,Tright,int(FRT*s))

    
    TD=np.concatenate([LeftTriangular,MiddleUniform,RightTriangular])
    
    return nr.choice(TD,s1)

